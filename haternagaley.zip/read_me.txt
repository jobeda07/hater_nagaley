Project Requiredment :

1. User table ->  id.1-> Guest User.
2. Category table -> id.1 -> 'Undefined Category'