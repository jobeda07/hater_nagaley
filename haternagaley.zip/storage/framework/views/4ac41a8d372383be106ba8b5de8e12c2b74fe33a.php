<div class="col-lg-1-5 col-md-4 col-sm-6 col-6">
    <div class="mb-10 product-cart-wrap wow animate__animated animate__fadeIn" data-wow-delay=".1s">
        <div class="product-img-action-wrap">
            <div class="product-img product-img-zoom">
                <a href="<?php echo e(route('product.details', $product->slug)); ?>">
                    <?php if($product->product_thumbnail && $product->product_thumbnail != '' && $product->product_thumbnail != ''): ?>
                        <img class="default-img lazyload img-responsive"
                            data-original="<?php echo e(asset($product->product_thumbnail)); ?>"
                            src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="">
                        <img class="hover-img" data-original="<?php echo e(asset($product->product_thumbnail)); ?>"
                            src="<?php echo e(asset($product->product_thumbnail)); ?>"alt="" />
                    <?php else: ?>
                        <img class="mb-3 img-lg" data-original="<?php echo e(asset('upload/no_image.jpg')); ?>" alt="" />
                    <?php endif; ?>
                </a>
            </div>
            <div class="product-action-1 d-flex">
                <a aria-label="Quick view" id="<?php echo e($product->id); ?>" onclick="productView(this.id)" class="action-btn"
                    data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fi-rs-eye"></i></a>
            </div>
            <!-- start product discount section -->
            <?php
                if (auth()->check() && auth()->user()->role == 7) {
                    if ($product->discount_type == 1) {
                        $price_after_discount = $product->reseller_price - $product->discount_price;
                    } elseif ($product->discount_type == 2) {
                        $price_after_discount =
                            $product->reseller_price - ($product->reseller_price * $product->discount_price) / 100;
                    }
                } else {
                    if ($product->discount_type == 1) {
                        $price_after_discount = $product->regular_price - $product->discount_price;
                    } elseif ($product->discount_type == 2) {
                        $price_after_discount =
                            $product->regular_price - ($product->regular_price * $product->discount_price) / 100;
                    }
                }
            ?>

            <?php if($product->discount_price > 0): ?>
                <div class="product-badges-right product-badges-position-right product-badges-mrg">
                    <?php if($product->discount_type == 1): ?>
                        <span class="hot">৳<?php echo e($product->discount_price); ?> <br> off</span>
                    <?php elseif($product->discount_type == 2): ?>
                        <span class="hot"><?php echo e($product->discount_price); ?>% <br> off</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="product-content-wrap">
            
            <h2 class="mt-2">
                <a href="<?php echo e(route('product.details', $product->slug)); ?>">
                    <?php if(session()->get('language') == 'bangla'): ?>
                        <?php echo e($product->name_bn); ?>

                    <?php else: ?>
                        <?php echo e($product->name_en); ?>

                    <?php endif; ?>

                    
                </a>
            </h2>

            

            
            <div class="product-card-bottom">
                <?php if($product->discount_price > 0): ?>
                    <?php if(auth()->check() && auth()->user()->role == 7): ?>
                        <div class="product-price">
                            <span class="price">৳<?php echo e($product->reseller_price); ?></span>
                            <!--<span class="old-price">৳<?php echo e($product->reseller_price); ?></span>-->
                        </div>
                    <?php else: ?>
                        <div class="product-price">
                            <span class="price">৳<?php echo e($price_after_discount); ?></span>
                            <span class="old-price">৳<?php echo e($product->regular_price); ?></span>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if(auth()->check() && auth()->user()->role == 7): ?>
                        <div class="product-price">
                            <span class="price">৳<?php echo e($product->reseller_price); ?></span>
                        </div>
                    <?php else: ?>
                        <div class="product-price">
                            <span class="price">৳<?php echo e($product->regular_price); ?></span>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
            <?php if(auth()->check() && auth()->user()->role == 7): ?>
                <div>
                    <span>Regular Price: <span class="text-info">৳ <?php echo e($product->regular_price); ?></span></span>
                    <input type="hidden" id="regular_price" name="regular_price" value="<?php echo e($product->regular_price); ?>"
                        min="1">
                </div>
            <?php endif; ?>
        </div>
        <div class="add-cart">
            <?php if($product->is_varient == 1): ?>
                <a class="add addBtn" id="<?php echo e($product->id); ?>" onclick="productView(this.id)"
                    data-bs-toggle="modal" data-bs-target="#quickViewModal">কার্ট </a>
                <a class="add addBuy" id="<?php echo e($product->id); ?>" onclick="productView(this.id)"
                    data-bs-toggle="modal" data-bs-target="#quickViewModal"
                        style="background: #AE6BCA">অর্ডার </a>
            <?php else: ?>
                <?php if($product->stock_qty > 0): ?>
                    <input type="hidden" id="pfrom" value="direct">
                    <input type="hidden" id="product_product_id" value="<?php echo e($product->id); ?>" min="1">
                    <input type="hidden" id="<?php echo e($product->id); ?>-product_pname" value="<?php echo e($product->name_en); ?>">

                    <a class="add addBtn" onclick="addToCartDirect(<?php echo e($product->id); ?>)"> কার্ট</a>
                    <a class="add addBuy" onclick="buyNowdirect(<?php echo e($product->id); ?>)"
                        style="background: #AE6BCA">অর্ডার </a>
                <?php else: ?>
                    <p class="stock_out w-100 bg-danger">স্টক আউট</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/common/product_grid_view.blade.php ENDPATH**/ ?>