<?php $__env->startSection('content-frontend-model'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-frontend'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            .container-fluid {
                max-width: 1610px;
                margin: auto;
            }

            .vertical-megamenu.category-item li a img {
                width: 22px;
                height: 22px;
                margin-right: 5px;
                display: inline-block;
            }

            .categories-dropdown-wrap.style-2 ul li:last-child {
                margin-bottom: 0
            }

            .categories-dropdown-wrap ul li a {
                font-weight: 600 !important;
            }

            .categories-dropdown-wrap.style-2 h4 {
                background: #0f1528;
                color: #fff;
                padding: 10px;
                border-radius: 10px 10px 0 0;
                margin-bottom: 10px;
                text-transform: capitalize;
                font-size: 20px;
            }

            .categories-dropdown-wrap.style-2 {
                padding: 0;
            }

            .vertical-megamenu.category-item {
                width: 100%;
            }

            ul.vertical-megamenu.category-item {
                padding: 10px;
                padding-top: 0;
            }

            .vertical-megamenu.category-item li a {
                position: relative;
                width: 100%
            }

            .categories-dropdown-wrap.style-2 ul li ul.subcategory {
                position: absolute;
                left: 100%;
                z-index: 999;
                background: #fff;
                border: 1px solid #ddd;
                padding: 10px;
                transition: all .5s ease-in-out;
                opacity: 0;
                width: 100%;
                visibility: hidden;
            }

            .categories-dropdown-wrap.style-2 ul li ul.subcategory li {
                width: 100%;
                margin: 0;
            }

            .categories-dropdown-wrap.style-2 ul li:hover ul.subcategory {
                opacity: 1;
                visibility: visible;
            }


            /* Normal desktop :1200px. */
            @media (min-width: 1200px) and (max-width: 1500px) {}


            /* Normal desktop :992px. */
            @media (min-width: 992px) and (max-width: 1200px) {}


            /* Tablet desktop :768px. */
            @media (min-width: 768px) and (max-width: 991px) {}


            /* small mobile :320px. */
            @media (max-width: 767px) {

                .footer-mid .widget-title {
                    margin: 0;
                    margin-bottom: 10px !important;
                }

                .product-cart-wrap.style-2 .product-content-wrap {
                    margin-top: 0;
                }

                .product-cart-wrap.style-2 .product-content-wrap .deals-content {
                    padding: 10px;
                }

                .product-card-bottom {
                     margin-top: 0 !important;
                }

                .product-cart-wrap .product-card-bottom .add-cart .add {
                    padding: 6px;
                    text-align: center;
                }
            }

            /* Large Mobile :480px. */
            @media  only screen and (min-width: 480px) and (max-width: 767px) {}
        </style>
    <?php $__env->stopPush(); ?>

    <?php echo $__env->make('frontend.common.add_to_cart_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="home-slider position-relative mb-30">
        <div class="container-fluid">
            <div class="row g-4">
                <div class="col-xl-2 col-lg-3 d-none d-lg-flex">
                    <div class="categories-dropdown-wrap style-2 font-heading mt-30 w-100">
                        <div class="categori-dropdown-inner">
                            <h4><i class="fa fa-bars"></i> categories</h4>
                            <ul class="vertical-megamenu category-item">
                                <?php $__currentLoopData = get_categories()->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('product.category', $category->slug)); ?>"><img
                                                src="<?php echo e(asset($category->image)); ?>" alt="">
                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                <?php echo e($category->name_bn); ?>

                                            <?php else: ?>
                                                <?php echo e($category->name_en); ?>

                                            <?php endif; ?>
                                            <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
                                                <i class="fi-rs-angle-right"></i>
                                            <?php endif; ?>
                                        </a>
                                        <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
                                            <ul class="subcategory">
                                                <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(route('product.category', $sub_category->slug)); ?>">
                                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                                <?php echo e($sub_category->name_bn); ?>

                                                            <?php else: ?>
                                                                <?php echo e($sub_category->name_en); ?>

                                                            <?php endif; ?>
                                                        </a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-10 col-lg-9">
                    <div class="slider__active">
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($slider->slider_url); ?>">
                                <div class="single__slider">
                                    <img src="<?php echo e(asset($slider->slider_img)); ?>" alt="">
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--End hero slider-->

    
    <div class="home__category">
        <div class="container-fluid">
            <div class="section-title">
                <h3>Top Categories</h3>
            </div>
            <div class="cat-product-container">
                <?php $__currentLoopData = $featured_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single__slider">
                        <a href="<?php echo e(route('product.category', $item->slug)); ?>">
                            <div class="cat-pro-wrapper">
                                <div class="cat-pro-img-container">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="" />
                                </div>
                                <div class="cat-pro-name">
                                    <a href="<?php echo e(route('product.category', $item->slug)); ?>" class="cat-pro-text">
                                        <?php if(session()->get('language') == 'bangla'): ?>
                                            <?php echo e($item->name_bn); ?>

                                        <?php else: ?>
                                            <?php echo e($item->name_en); ?>

                                        <?php endif; ?>
                                    </a>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    

    <!-- Campaign Slider Start-->
    <?php
        $campaign = \App\Models\Campaing::where('status', 1)->where('is_featured', 1)->first();
    ?>

    <?php if($campaign): ?>
        <?php
            $start_diff = date_diff(date_create($campaign->flash_start ?? ''), date_create(date('d-m-Y H:i:s')));
            $end_diff = date_diff(date_create(date('d-m-Y H:i:s')), date_create($campaign->flash_end ?? ''));
        ?>

        <?php if($start_diff->invert == 0 && $end_diff->invert == 0): ?>
            <section class="common-product section-padding">
                <div class="container wow animate__animated animate__fadeIn">
                    <div class="section-title">
                        <div class="title">
                            <div class="d-flex align-items-center w-100" style="justify-content: space-between">
                                <h3>My Campaign Sell</h3>
                                
                            </div>

                            <div class="deals-countdown-wrap">
                                <div class="deals-countdown"
                                    data-countdown="<?php echo e(date('Y-m-d H:i:s', strtotime($campaign->flash_end))); ?>"></div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="carausel-5-columns-cover position-relative">
                        <div class="slider-arrow slider-arrow-2 carausel-5-columns-common-arrow"
                            id="carausel-5-columns-common-arrows"></div>
                        <div class="carausel-5-columns-common carausel-arrow-center" id="carausel-5-columns-common">
                            <?php $__currentLoopData = $campaign->campaing_products->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaing_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $product = \App\Models\Product::find($campaing_product->product_id);
                                ?>
                                <?php if($product != null && $product->status != 0): ?>
                                    <?php echo $__env->make('frontend.common.product_grid_view', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>
    <!-- Campaign Slider End-->

    <section class="product-tabs section-padding position-relative">
        <div class="container-fluid">
            <div class="section-title style-2 wow animate__animated animate__fadeIn">
                <h3>Featured Products</h3>
                <ul class="nav nav-tabs links" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="nav-tab-one" data-bs-toggle="tab" data-bs-target="#tab-one"
                            type="button" role="tab" aria-controls="tab-one" aria-selected="true">All</button>
                    </li>
                    <?php $__currentLoopData = get_categories()->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="nav-tab-two" data-bs-toggle="tab"
                                data-bs-target="#category<?php echo e($category->id); ?>" type="button" role="tab"
                                aria-controls="tab-two" aria-selected="false"><?php echo e($category->name_en); ?></button>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <!--End nav-tabs-->
            <div class="tab-content common-product" id="myTabContent">
                <div class="tab-pane fade show active" id="tab-one" role="tabpanel" aria-labelledby="tab-one">
                    <div class="carausel-6-columns-common-cover position-relative">
                        <div class="slider-arrow slider-arrow-2 carausel-6-columns-common"
                            id="carausel-6-columns-common-arrows"></div>
                        <div class="carausel-6-columns-common carausel-arrow-center" id="carausel-6-columns-common">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('frontend.common.product_grid_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <!--end product card-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php if(session()->get('language') == 'bangla'): ?>
                                    <h5 class="text-danger">এখানে কোন পণ্য খুঁজে পাওয়া যায়নি!</h5>
                                <?php else: ?>
                                    <h5 class="text-danger">No products were found here!</h5>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--End product-grid-4-->
                </div>
                <!--En tab one-->
                <?php $__currentLoopData = get_categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade" id="category<?php echo e($category->id); ?>" role="tabpanel" aria-labelledby="tab-two">
                        <?php
                            $products = get_category_products($category->slug);
                        ?>
                        <div class="row product-grid-4">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('frontend.common.product_grid_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php if(session()->get('language') == 'bangla'): ?>
                                    <h5 class="text-danger">এখানে কোন পণ্য খুঁজে পাওয়া যায়নি!</h5>
                                <?php else: ?>
                                    <h5 class="text-danger">No products were found here!</h5>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <!--End product-grid-4-->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!--En tab two-->
            </div>
            <!--End tab-content-->
        </div>
    </section>
    <!--Products Tabs-->

    <section class="banners mb-25">
        <div class="container-fluid">
            <div class="row g-4">
                <?php $__currentLoopData = $home_banners->skip(2)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6">
                        <div class="banner-img wow animate__animated animate__fadeInUp" data-wow-delay="0">
                            <img src="<?php echo e(asset($banner->banner_img)); ?>" class="img-fluid" alt="" />
                            <div class="banner-text">
                                <h4>
                                    <?php if(session()->get('language') == 'bangla'): ?>
                                        <?php echo e($banner->title_bn); ?>

                                    <?php else: ?>
                                        <?php echo e($banner->title_en); ?>

                                    <?php endif; ?>
                                </h4>
                                <a href="<?php echo e($banner->banner_url); ?>" class="btn btn-xs">Shop Now <i
                                        class="fi-rs-arrow-small-right"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--End banners-->

    <?php if(count($home2_featured_categories) > 0): ?>
        <?php $__currentLoopData = $home2_featured_categories->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home2_featured_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($home2_featured_category->products) > 0): ?>
                <section class="common-product section-padding">
                    <div class="container wow animate__animated animate__fadeIn">
                        <div class="section-title">
                            <?php if(count($home2_featured_category->products->where('status', 1)) > 0): ?>
                                <div class="title">
                                    <h3>


                                        <?php if(session()->get('language') == 'bangla'): ?>
                                            <?php echo e($home2_featured_category->name_bn); ?>

                                        <?php else: ?>
                                            <?php echo e($home2_featured_category->name_en); ?>

                                        <?php endif; ?>
                                    </h3>
                                </div>
                                <a href="<?php echo e(route('product.category', $home2_featured_category->slug)); ?>"
                                    class="btn btn-sm btn-primary">View more</a>
                            <?php endif; ?>
                        </div>
                        <div class="carausel-5-columns-cover position-relative">
                            <div class="carausel-5-columns-common carausel-arrow-center"
                                id="carausel-5-columns-common<?php echo e($home2_featured_category->id); ?>">

                                <?php $__empty_1 = true; $__currentLoopData = $home2_featured_category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($product->status == 1): ?>
                                        <?php echo $__env->make('frontend.common.product_grid_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                    <!--end product card-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php if(session()->get('language') == 'bangla'): ?>
                                        <h5 class="text-danger">এখানে কোন পণ্য খুঁজে পাওয়া যায়নি!</h5>
                                    <?php else: ?>
                                        <h5 class="text-danger">No products were found here!</h5>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!--Products Tabs-->
    <!--End 4 banners-->
    <?php if(count($todays_sale) > 0): ?>
        <section class="pb-5 section-padding">
            <div class="container-fluid">
                <div class="section-title wow animate__animated animate__fadeIn">
                    <h3 class="">Daily Best Sells</h3>
                    <ul class="nav nav-tabs links" id="myTab-2" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="nav-tab-one-1" data-bs-toggle="tab"
                                data-bs-target="#tab-one-1" type="button" role="tab" aria-controls="tab-one"
                                aria-selected="true"></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="nav-tab-two-1" data-bs-toggle="tab" data-bs-target="#tab-two-1"
                                type="button" role="tab" aria-controls="tab-two" aria-selected="false"></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="nav-tab-three-1" data-bs-toggle="tab"
                                data-bs-target="#tab-three-1" type="button" role="tab" aria-controls="tab-three"
                                aria-selected="false"></button>
                        </li>
                    </ul>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-9 col-md-12 wow animate__animated animate__fadeIn" data-wow-delay=".4s">
                        <div class="tab-content" id="myTabContent-1">
                            <div class="tab-pane fade show active" id="tab-one-1" role="tabpanel"
                                aria-labelledby="tab-one-1">
                                <div class="carausel-4-columns-cover arrow-center position-relative">
                                    <div class="slider-arrow slider-arrow-2 carausel-4-columns-arrow"
                                        id="carausel-4-columns-arrows"></div>
                                    <div class="carausel-4-columns carausel-arrow-center" id="carausel-4-columns">
                                        <?php $__currentLoopData = $todays_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $today_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $product = \App\Models\Product::find($today_product->product_id);
                                            ?>
                                            <?php if($product): ?>
                                                <?php echo $__env->make('frontend.common.product_grid_view', [
                                                    'product' => $product,
                                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <!--End product Wrap-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End tab-content-->
                    </div>
                    <!--End Col-lg-9-->
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if(count($hot_deals) > 0): ?>
        <!-- Start Hot Deals -->
        <section class="pb-5 section-padding">
            <div class="container-fluid">
                <div class="section-title wow animate__animated animate__fadeIn" data-wow-delay="0">
                    <h3 class="">Hot Deals</h3>
                    <a class="text-white show-all btn btn-primary" href="<?php echo e(route('hot_deals.all')); ?>">
                        All Deals
                        <i class="fi-rs-angle-right"></i>
                    </a>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $hot_deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('frontend.common.deals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!--end product card-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <!-- End Hot Deals -->
    <?php endif; ?>

    <!--End Deals-->
    <section class="section-padding">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-4 col-md-6 mb-sm-5 mb-md-0 col-sm-6 col-12 wow animate__animated animate__fadeInUp"
                    data-wow-delay="0">
                    <h4 class="section-title style-1 mb-30 animated">Top Selling</h4>
                    <div class="product-list-small animated">
                        <?php $__currentLoopData = $product_top_sellings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_top_selling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="row align-items-center hover-up">
                                <figure class="mb-0 col-md-4">
                                    <a href="<?php echo e(route('product.details', $product_top_selling->slug)); ?>">
                                        <?php if(
                                            $product_top_selling->product_thumbnail &&
                                                $product_top_selling->product_thumbnail != '' &&
                                                $product_top_selling->product_thumbnail != 'Null'): ?>
                                            <img class="default-img"
                                                src="<?php echo e(asset($product_top_selling->product_thumbnail)); ?>"
                                                alt="" />
                                        <?php else: ?>
                                            <img class="mb-3 img-lg" src="<?php echo e(asset('upload/no_image.jpg')); ?>"
                                                alt="" />
                                        <?php endif; ?>
                                    </a>
                                </figure>
                                <div class="mb-0 col-md-8">
                                    <h6>
                                        <a href="<?php echo e(route('product.details', $product_top_selling->slug)); ?>">
                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                <?php echo e($product_top_selling->name_bn); ?>

                                            <?php else: ?>
                                                <?php echo e($product_top_selling->name_en); ?>

                                            <?php endif; ?>
                                        </a>
                                    </h6>
                                    <div class="product-rate-cover">
                                        <div class="product-rate d-inline-block">
                                            <div class="product-rating" style="width: 90%"></div>
                                        </div>
                                        <span class="ml-5 font-small text-muted"> (4.0)</span>
                                    </div>
                                    <?php
                                        if (auth()->check() && auth()->user()->role == 7) {
                                            if ($product_top_selling->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_top_selling->reseller_price -
                                                    $product_top_selling->discount_price;
                                            } elseif ($product_top_selling->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_top_selling->reseller_price -
                                                    ($product_top_selling->reseller_price *
                                                        $product_top_selling->discount_price) /
                                                        100;
                                            }
                                        } else {
                                            if ($product_top_selling->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_top_selling->regular_price -
                                                    $product_top_selling->discount_price;
                                            } elseif ($product_top_selling->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_top_selling->regular_price -
                                                    ($product_top_selling->regular_price *
                                                        $product_top_selling->discount_price) /
                                                        100;
                                            }
                                        }
                                    ?>

                                    <?php if($product_top_selling->discount_price > 0): ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span class="old-price">৳<?php echo e($product_top_selling->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span class="old-price">৳<?php echo e($product_top_selling->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_top_selling->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_top_selling->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 mb-md-0 wow col-sm-6 col-12 animate__animated animate__fadeInUp"
                    data-wow-delay=".1s">
                    <h4 class="section-title style-1 mb-30 animated">Trending Products</h4>
                    <div class="product-list-small animated">
                        <?php $__currentLoopData = $product_trendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="row align-items-center hover-up">
                                <figure class="mb-0 col-md-4">
                                    <a href="<?php echo e(route('product.details', $product_trending->slug)); ?>">
                                        <?php if(
                                            $product_trending->product_thumbnail &&
                                                $product_trending->product_thumbnail != '' &&
                                                $product_trending->product_thumbnail != 'Null'): ?>
                                            <img class="default-img"
                                                src="<?php echo e(asset($product_trending->product_thumbnail)); ?>" alt="" />
                                        <?php else: ?>
                                            <img class="mb-3 img-lg" src="<?php echo e(asset('upload/no_image.jpg')); ?>"
                                                alt="" />
                                        <?php endif; ?>
                                    </a>
                                </figure>
                                <div class="mb-0 col-md-8">
                                    <h6>
                                        <a href="<?php echo e(route('product.details', $product_trending->slug)); ?>">
                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                <?php echo e($product_trending->name_bn); ?>

                                            <?php else: ?>
                                                <?php echo e($product_trending->name_en); ?>

                                            <?php endif; ?>
                                        </a>
                                    </h6>
                                    <div class="product-rate-cover">
                                        <div class="product-rate d-inline-block">
                                            <div class="product-rating" style="width: 90%"></div>
                                        </div>
                                        <span class="ml-5 font-small text-muted"> (4.0)</span>
                                    </div>
                                    <?php
                                        if (auth()->check() && auth()->user()->role == 7) {
                                            if ($product_trending->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_trending->reseller_price -
                                                    $product_trending->discount_price;
                                            } elseif ($product_trending->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_trending->reseller_price -
                                                    ($product_trending->reseller_price *
                                                        $product_trending->discount_price) /
                                                        100;
                                            }
                                        } else {
                                            if ($product_trending->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_trending->regular_price -
                                                    $product_trending->discount_price;
                                            } elseif ($product_trending->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_trending->regular_price -
                                                    ($product_trending->regular_price *
                                                        $product_trending->discount_price) /
                                                        100;
                                            }
                                        }
                                    ?>
                                    <?php if($product_trending->discount_price > 0): ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span class="old-price">৳<?php echo e($product_trending->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span class="old-price">৳<?php echo e($product_trending->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_trending->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_trending->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 mb-sm-5 mb-md-0 col-sm-6 col-12 wow animate__animated animate__fadeInUp"
                    data-wow-delay=".2s">
                    <h4 class="section-title style-1 mb-30 animated">Recently added</h4>
                    <div class="product-list-small animated">
                        <?php $__currentLoopData = $product_recently_adds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_recently_add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="row align-items-center hover-up">
                                <figure class="mb-0 col-md-4">
                                    <a href="<?php echo e(route('product.details', $product_recently_add->slug)); ?>">
                                        <?php if(
                                            $product_recently_add->product_thumbnail &&
                                                $product_recently_add->product_thumbnail != '' &&
                                                $product_recently_add->product_thumbnail != 'Null'): ?>
                                            <img class="default-img"
                                                src="<?php echo e(asset($product_recently_add->product_thumbnail)); ?>"
                                                alt="" />
                                        <?php else: ?>
                                            <img class="mb-3 img-lg" src="<?php echo e(asset('upload/no_image.jpg')); ?>"
                                                alt="" />
                                        <?php endif; ?>
                                    </a>
                                </figure>
                                <div class="mb-0 col-md-8">
                                    <h6>
                                        <a href="<?php echo e(route('product.details', $product_recently_add->slug)); ?>">
                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                <?php echo e($product_recently_add->name_bn); ?>

                                            <?php else: ?>
                                                <?php echo e($product_recently_add->name_en); ?>

                                            <?php endif; ?>
                                        </a>
                                    </h6>
                                    <div class="product-rate-cover">
                                        <div class="product-rate d-inline-block">
                                            <div class="product-rating" style="width: 90%"></div>
                                        </div>
                                        <span class="ml-5 font-small text-muted"> (4.0)</span>
                                    </div>
                                    <?php
                                        if (auth()->check() && auth()->user()->role == 7) {
                                            if ($product_recently_add->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_recently_add->reseller_price -
                                                    $product_recently_add->discount_price;
                                            } elseif ($product_recently_add->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_recently_add->reseller_price -
                                                    ($product_recently_add->reseller_price *
                                                        $product_recently_add->discount_price) /
                                                        100;
                                            }
                                        } else {
                                            if ($product_recently_add->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_recently_add->regular_price -
                                                    $product_recently_add->discount_price;
                                            } elseif ($product_recently_add->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_recently_add->regular_price -
                                                    ($product_recently_add->regular_price *
                                                        $product_recently_add->discount_price) /
                                                        100;
                                            }
                                        }
                                    ?>
                                    <?php if($product_recently_add->discount_price > 0): ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span
                                                    class="old-price">৳<?php echo e($product_recently_add->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span class="old-price">৳<?php echo e($product_recently_add->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_recently_add->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_recently_add->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 mb-sm-5 mb-md-0 col-sm-6 col-12 wow animate__animated animate__fadeInUp"
                    data-wow-delay=".3s">
                    <h4 class="section-title style-1 mb-30 animated">Top Rated</h4>
                    <div class="product-list-small animated">
                        <?php $__currentLoopData = $product_top_rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_top_rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="row align-items-center hover-up">
                                <figure class="mb-0 col-md-4">
                                    <a href="<?php echo e(route('product.details', $product_top_rate->slug)); ?>">
                                        <?php if(
                                            $product_top_rate->product_thumbnail &&
                                                $product_top_rate->product_thumbnail != '' &&
                                                $product_top_rate->product_thumbnail != 'Null'): ?>
                                            <img class="default-img"
                                                src="<?php echo e(asset($product_top_rate->product_thumbnail)); ?>" alt="" />
                                        <?php else: ?>
                                            <img class="mb-3 img-lg" src="<?php echo e(asset('upload/no_image.jpg')); ?>"
                                                alt="" />
                                        <?php endif; ?>
                                    </a>
                                </figure>
                                <div class="mb-0 col-md-8">
                                    <h6>
                                        <a href="<?php echo e(route('product.details', $product_top_rate->slug)); ?>">
                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                <?php echo e($product_top_rate->name_bn); ?>

                                            <?php else: ?>
                                                <?php echo e($product_top_rate->name_en); ?>

                                            <?php endif; ?>
                                        </a>
                                    </h6>
                                    <div class="product-rate-cover">
                                        <div class="product-rate d-inline-block">
                                            <div class="product-rating" style="width: 90%"></div>
                                        </div>
                                        <span class="ml-5 font-small text-muted"> (4.0)</span>
                                    </div>
                                    <?php
                                        if (auth()->check() && auth()->user()->role == 7) {
                                            if ($product_top_rate->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_top_rate->reseller_price -
                                                    $product_top_rate->discount_price;
                                            } elseif ($product_top_rate->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_top_rate->reseller_price -
                                                    ($product_top_rate->reseller_price *
                                                        $product_top_rate->discount_price) /
                                                        100;
                                            }
                                        } else {
                                            if ($product_top_rate->discount_type == 1) {
                                                $price_after_discount =
                                                    $product_top_rate->regular_price -
                                                    $product_top_rate->discount_price;
                                            } elseif ($product_top_rate->discount_type == 2) {
                                                $price_after_discount =
                                                    $product_top_rate->regular_price -
                                                    ($product_top_rate->regular_price *
                                                        $product_top_rate->discount_price) /
                                                        100;
                                            }
                                        }
                                    ?>
                                    <?php if($product_top_rate->discount_price > 0): ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span class="old-price">৳<?php echo e($product_top_rate->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($price_after_discount); ?></span>
                                                <span class="old-price">৳<?php echo e($product_top_rate->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_top_rate->reseller_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-start product-price">
                                                <span class="price">৳<?php echo e($product_top_rate->regular_price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End 4 columns-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/home2.blade.php ENDPATH**/ ?>