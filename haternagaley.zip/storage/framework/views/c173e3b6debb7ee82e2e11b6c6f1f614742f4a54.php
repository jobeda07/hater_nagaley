<?php
    $couponCode = getCoupon();
?>
<header class="header-area header-style-1 header-height-2">
    <div class="header-top header-top-ptb-1 d-none d-lg-block">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4">
                    <div class="header-info">
                        <ul>
                            <li class="contact_header">Need help? Call Us: <strong class="text-brand"> <a
                                        class="text-brand" href="tel:<?php echo e(get_setting('phone')->value ?? 'null'); ?>"><i
                                            class="fa fa-phone ms-1"></i>
                                        <?php echo e(get_setting('phone')->value ?? 'null'); ?></a></strong></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center">
                        <div id="news-flash" class="d-inline-block">
                            <ul>
                                <li>100% Secure delivery without contacting the courier</li>
                                <li>Supper Value Deals - Save more with coupons</li>
                                <li>Trendy 25silver jewelry, save up 35% off today</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="header-info header-info-right">

                        <ul>
                            <li><a href="#" class="btn btn-primary reseller" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">Apply as Reseller</a></li>
                            <li><a href="#" class="btn btn-primary reseller" data-bs-toggle="modal"
                                    data-bs-target="#vendor_service">Become a Vendor</a></li>
                            <li><a href="#">Order Tracking</a></li>
                            <li>
                                <?php if(session()->get('language') == 'bangla'): ?>
                                    <a class="language-dropdown-active"
                                        href="<?php echo e(route('english.language')); ?>">English</a>
                                <?php else: ?>
                                    <a class="language-dropdown-active" href="<?php echo e(route('bangla.language')); ?>">বাংলা</a>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="d-lg-block">
        <div class="header-middle header-middle-ptb-1 d-none d-lg-block">
            <div class="container">
                
                <div class="header-wrap">
                    <div class="logo logo-width-1">
                        <a href="<?php echo e(route('home')); ?>">
                            <?php
                                $logo = get_setting('site_logo');
                            ?>
                            <?php if($logo != null): ?>
                                <img src="<?php echo e(asset(get_setting('site_logo')->value ?? 'null')); ?>"
                                    alt="<?php echo e(env('APP_NAME')); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('upload/no_image.jpg')); ?>" alt="<?php echo e(env('APP_NAME')); ?>"
                                    style="height: 60px !important; width: 80px !important; min-width: 80px !important;">
                            <?php endif; ?>
                        </a>
                    </div>
                    <div class="header-right">
                        <div class="search-style-2">
                            <div class="search-area">
                                <form action="<?php echo e(route('product.search')); ?>" method="post" class="mx-auto">
                                    <?php echo csrf_field(); ?>
                                    <select class="select-active" name="searchCategory" id="searchCategory">
                                        <option value="0">All Categories</option>
                                        <?php $__currentLoopData = get_all_categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>">
                                                <?php if(session()->get('language') == 'bangla'): ?>
                                                    <?php echo e($cat->name_bn); ?>

                                                <?php else: ?>
                                                    <?php echo e($cat->name_en); ?>

                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input class="search-field search" onfocus="search_result_show()"
                                        onblur="search_result_hide()" name="search" placeholder="Search here..." />
                                    <div>
                                        <button type="submit"
                                            class="bg-brand btn btn-primary text-white btn-sm rounded-0"><i
                                                class="fa-solid fa-magnifying-glass"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="shadow-lg searchProducts"></div>
                        </div>
                        <div class="header-action-right">
                            <div class="header-action-2">
                                <div class="header-action-2 cart_hidden_mobile me-2">
                                    <div class="header-action-icon-2">
                                        <a class="mini-cart-icon" href="#">
                                            <img alt="Nest"
                                                src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-cart.png')); ?>" />
                                            <span class="pro-count blue cartQty"></span>
                                        </a>
                                        <a href="<?php echo e(route('cart.show')); ?>"><span class="lable">Cart</span></a>
                                        <div class="cart-dropdown-wrap cart-dropdown-hm2">
                                            <div id="miniCart">

                                            </div>
                                            <div class="shopping-cart-footer" id="miniCart_btn">
                                                <div class="shopping-cart-total">
                                                    <h4>Total <span id="cartSubTotal"></span></h4>
                                                </div>
                                                <div class="shopping-cart-button">
                                                    <a href="<?php echo e(route('cart.show')); ?>" class="outline">View cart</a>
                                                    <a href="<?php echo e(route('checkout')); ?>">Checkout</a>
                                                </div>
                                            </div>
                                            <div class="shopping-cart-footer" id="miniCart_empty_btn">

                                                <div class="shopping-cart-button d-flex flex-row-reverse">
                                                    <a href="<?php echo e(route('home')); ?>">Continue Shopping</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="header-action-icon-2">
                                    <?php if(auth()->guard()->check()): ?>
                                        <a href="#">
                                            <img class="svgInject" alt="Nest"
                                                src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-user.svg')); ?>" />
                                        </a>
                                        <a href="<?php echo e(route('dashboard')); ?>"><span class="lable ml-0">Account</span></a>
                                        <div class="cart-dropdown-wrap cart-dropdown-hm2 account-dropdown">
                                            <ul>
                                                <li>
                                                    <a href="<?php echo e(route('dashboard')); ?>"><i
                                                            class="fi fi-rs-user mr-10"></i>My Account</a>
                                                </li>
                                                
                                                <li>
                                                    <a class=" mr-10" href="<?php echo e(route('logout')); ?>"
                                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                        <i class="fi-rs-sign-out mr-10"></i>
                                                        <?php echo e(__('Logout')); ?>

                                                    </a>
                                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                        class="d-none">
                                                        <?php echo csrf_field(); ?>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(auth()->guard()->guest()): ?>
                                        <a href="<?php echo e(route('login')); ?>"><span class="lable ml-0"><i
                                                    class="fa-solid fa-arrow-right-to-bracket mr-10"></i>Login</span></a>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom header-bottom-bg-color">
            <div class="container">
                <div class="header-wrap header-space-between position-relative">
                    <div class="logo logo-width-1 d-block d-lg-none">
                        <a href="<?php echo e(route('home')); ?>">
                            <?php
                                $logo = get_setting('site_logo');
                            ?>
                            <?php if($logo != null): ?>
                                <img src="<?php echo e(asset(get_setting('site_logo')->value ?? 'null')); ?>"
                                    alt="<?php echo e(env('APP_NAME')); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('upload/no_image.jpg')); ?>" alt="<?php echo e(env('APP_NAME')); ?>"
                                    style="height: 60px !important; width: 80px !important; min-width: 80px !important;">
                            <?php endif; ?>
                        </a>
                    </div>
                    <div class="header-nav d-none d-lg-flex">
                        <div class="main-categori-wrap d-none d-lg-block">
                            <a class="campaign" href="<?php echo e(route('product.campaing')); ?>">
                                <span>
                                    <?php if(session()->get('language') == 'bangla'): ?>
                                        প্রচারণা
                                    <?php else: ?>
                                        Campaign
                                    <?php endif; ?>
                                </span>
                            </a>
                        </div>
                        <div class="main-menu main-menu-padding-1 main-menu-lh-2 d-none d-lg-block font-heading">
                            <nav>
                                <ul>
                                    <li>
                                        <a href="<?php echo e(route('home')); ?>">
                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                হোম
                                            <?php else: ?>
                                                Home
                                            <?php endif; ?>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('product.show')); ?>">
                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                দোকান
                                            <?php else: ?>
                                                Shop
                                            <?php endif; ?>
                                        </a>
                                    </li>
                                    <!-- Start Mega Menu -->
                                    <?php $__currentLoopData = get_categories()->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($category->has_sub_sub > 0): ?>
                                            <li class="position-static">
                                                <a href="<?php echo e(route('product.category', $category->slug)); ?>">
                                                    <?php if(session()->get('language') == 'bangla'): ?>
                                                        <?php echo e($category->name_bn); ?>

                                                    <?php else: ?>
                                                        <?php echo e($category->name_en); ?>

                                                    <?php endif; ?>
                                                    <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
                                                        <i class="fi-rs-angle-down"></i>
                                                    <?php endif; ?>
                                                </a>
                                                <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
                                                    <ul class="mega-menu">
                                                        <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="sub-mega-menu sub-mega-menu-width-22">
                                                                <a class="menu-title"
                                                                    href="<?php echo e(route('product.category', $sub_category->slug)); ?>">
                                                                    <?php if(session()->get('language') == 'bangla'): ?>
                                                                        <?php echo e($sub_category->name_bn); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e($sub_category->name_en); ?>

                                                                    <?php endif; ?>
                                                                </a>
                                                                <?php if($sub_category->sub_sub_categories && count($sub_category->sub_sub_categories) > 0): ?>
                                                                    <ul>
                                                                        <?php $__currentLoopData = $sub_category->sub_sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <li><a
                                                                                    href="<?php echo e(route('product.category', $sub_sub_category->slug)); ?>">
                                                                                    <?php if(session()->get('language') == 'bangla'): ?>
                                                                                        <?php echo e($sub_sub_category->name_bn); ?>

                                                                                    <?php else: ?>
                                                                                        <?php echo e($sub_sub_category->name_en); ?>

                                                                                    <?php endif; ?>
                                                                                </a></li>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </ul>
                                                                <?php endif; ?>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </li>
                                        <?php else: ?>
                                            <li>
                                                <a href="<?php echo e(route('product.category', $category->slug)); ?>">
                                                    <?php if(session()->get('language') == 'bangla'): ?>
                                                        <?php echo e($category->name_bn); ?>

                                                    <?php else: ?>
                                                        <?php echo e($category->name_en); ?>

                                                    <?php endif; ?>
                                                    <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
                                                        <i class="fi-rs-angle-down"></i>
                                                    <?php endif; ?>
                                                </a>

                                                <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
                                                    <ul class="sub-menu">
                                                        <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a
                                                                    href="<?php echo e(route('product.category', $sub_category->slug)); ?>"><?php echo e($sub_category->name_en); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <!-- End Mega Menu -->
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <div class="header-action-icon-2 d-block d-lg-none">
                        <div class="burger-icon burger-icon-white">
                            <span class="burger-icon-top"></span>
                            <span class="burger-icon-mid"></span>
                            <span class="burger-icon-bottom"></span>
                        </div>
                    </div>
                    <div class="header-action-right d-block d-lg-none">
                        <div class="header-action-2">
                            <!--Mobile Header Search start-->
                            <a class="p-2 d-block text-reset active show">
                                <i class="fas fa-search la-flip-horizontal la-2x"></i>
                            </a>

                            <section class="advance-search" style="display: none;">
                                <div class="search-box">
                                    <form action="<?php echo e(route('product.search')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="input-group py-2">
                                            <span class="back_left hide"><i
                                                    class="fas fa-long-arrow-left me-2"></i></span>
                                            <input class="header-search form-control search-field search"
                                                aria-label="Input group example" aria-describedby="btnGroupAddon"
                                                onfocus="search_result_show()" onblur="search_result_hide()"
                                                name="search" placeholder="Search here..." />
                                            <button type="submit" class="input-group-text btn btn-sm"
                                                id="btnGroupAddon"><i class="fas fa-search"></i></button>
                                        </div>
                                    </form>
                                    <div class="shadow-lg searchProducts"></div>
                                </div>
                            </section>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom-1 header-bottom-bg-color sticky-bar d-lg-none">
        <div class="container">
            <ul class="mobile-hor-swipe header-wrap header-space-between position-relative">
                <?php $__currentLoopData = get_categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="mb-10">
                        <a class="p-10" href="<?php echo e(route('product.category', $category->slug)); ?>">
                            <?php if(session()->get('language') == 'bangla'): ?>
                                <?php echo e($category->name_bn); ?>

                            <?php else: ?>
                                <?php echo e($category->name_en); ?>

                            <?php endif; ?>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</header>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                    <div class="heading_s1">
                        <h5 class="mb-5">Apply as a Reseller</h1>
                    </div>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="page-content pt-10 pb-10">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="login_wrap widget-taber-content background-white">
                                    <div class="padding_eight_all bg-white">
                                        <form method="POST" action="<?php echo e(route('resellerApply')); ?>"
                                            class="needs-validation" novalidate>
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="name" class="fw-900">Name : *</label>
                                                <input type="text" name="name" placeholder="Name"
                                                    id="name" value="<?php echo e(old('name')); ?>" required />
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger" style="font-weight: bold;">
                                                        <?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="username" class="fw-900">User Name : *</label>
                                                <input type="text" name="username" placeholder="Username"
                                                    id="username" value="<?php echo e(old('username')); ?>" required />
                                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger" style="font-weight: bold;">
                                                        <?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="phone" class="fw-900">Phone Number : *</label>
                                                <input type="number" name="phone" id="phone"
                                                    placeholder="Phone Number" value="<?php echo e(old('phone')); ?>"
                                                    required />
                                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger" style="font-weight: bold;">
                                                        <?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="email" class="fw-900">Email : *</label>
                                                <input type="email" name="email" id="email"
                                                    placeholder="Email" value="<?php echo e(old('email')); ?>" required />
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger" style="font-weight: bold;">
                                                        <?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="password" class="fw-900">Password : *</label>
                                                <input type="password" name="password" placeholder="Password"
                                                    id="password" autocomplete="new-password" required />
                                                <span>password must be at least 8 characters</span>
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger" style="font-weight: bold;">
                                                        <?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="fw-900">Confirm password : *</label>
                                                <input type="password" placeholder="Confirm password"
                                                    name="password_confirmation" required />
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger" style="font-weight: bold;">
                                                        <?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="login_footer form-group mb-50">
                                                <div class="chek-form">
                                                    <div class="custome-checkbox">
                                                        <input class="form-check-input" type="checkbox"
                                                            name="checkbox" id="exampleCheckbox12" value=""
                                                            required />
                                                        <label class="form-check-label"
                                                            for="exampleCheckbox12"><span>I agree to terms
                                                                &amp; Policy.</span></label>
                                                    </div>
                                                </div>
                                                <a href="#"><i class="fi-rs-book-alt mr-5 text-muted"></i>Lean
                                                    more</a>
                                            </div>
                                            <div class="form-group mb-30 seller__btn">
                                                <button type="button" class=" btn-secondary "
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn-primary " name="login">Submit
                                                    &amp; Register</button>
                                            </div>
                                            <p class="font-xs text-muted"><strong>Note:</strong>Your personal
                                                data will be used to support your experience throughout this
                                                website, to manage access to your account, and for other
                                                purposes described in our privacy policy</p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Mobile Side menu Start -->
<div class="mobile-header-active mobile-header-wrapper-style">
    <div class="mobile-header-wrapper-inner">
        <div class="mobile-header-top">
            <div class="mobile-header-logo">
                <a href="<?php echo e(route('home')); ?>">
                    <?php
                        $logo = get_setting('site_logo');
                    ?>
                    <?php if($logo != null): ?>
                        <img src="<?php echo e(asset(get_setting('site_logo')->value ?? 'null')); ?>"
                            alt="<?php echo e(env('APP_NAME')); ?>">
                    <?php else: ?>
                        <img src="<?php echo e(asset('upload/no_image.jpg')); ?>" alt="<?php echo e(env('APP_NAME')); ?>"
                            style="height: 60px !important; width: 80px !important; min-width: 80px !important;">
                    <?php endif; ?>
                </a>
            </div>
            <div class="mobile-menu-close close-style-wrap close-style-position-inherit">
                <button class="close-style search-close">
                    <i class="icon-top"></i>
                    <i class="icon-bottom"></i>
                </button>
            </div>
        </div>
        <div class="mobile-header-content-area">
            
            <div class="mobile-menu-wrap mobile-header-border">
                <!-- mobile menu start -->
                <nav>
                    <ul class="mobile-menu font-heading">
                        <!--<li class="menu-item-has-children">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                        </li>
                        <li class="menu-item-has-children">
                            <a href="<?php echo e(route('product.show')); ?>">
                                <?php if(session()->get('language') == 'bangla'): ?>
দোকান
<?php else: ?>
Shop
<?php endif; ?>
                            </a>
                        </li>-->
                        <?php $__currentLoopData = get_categories()->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(route('product.category', $cat->slug)); ?>">
                                    <?php if(session()->get('language') == 'bangla'): ?>
                                        <?php echo e($cat->name_bn); ?>

                                    <?php else: ?>
                                        <?php echo e($cat->name_en); ?>

                                    <?php endif; ?>
                                </a>
                                <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
                                    <ul class="dropdown">
                                        <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('product.category', $subcategory->slug)); ?>">
                                                    <?php if(session()->get('language') == 'bangla'): ?>
                                                        <?php echo e($subcategory->name_bn); ?>

                                                    <?php else: ?>
                                                        <?php echo e($subcategory->name_en); ?>

                                                    <?php endif; ?>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($subcategory->sub_sub_categories && count($subcategory->sub_sub_categories) > 0): ?>
                                            <ul class="dropdown">
                                                <?php $__currentLoopData = $subcategory->sub_sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a
                                                            href="<?php echo e(route('product.category', $subsubcategory->slug)); ?>">
                                                            <?php if(session()->get('language') == 'bangla'): ?>
                                                                <?php echo e($subsubcategory->name_bn); ?>

                                                            <?php else: ?>
                                                                <?php echo e($subsubcategory->name_en); ?>

                                                            <?php endif; ?>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--<li class="menu-item-has-children">-->
                        <!--    <a href="<?php echo e(route('category_list.index')); ?>">Category</a>-->
                        <!--    <ul class="dropdown">-->
                        <!--        <?php $__currentLoopData = get_categories()->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                        <!--            <li class="menu-item-has-children">-->
                        <!--                <a href="<?php echo e(route('product.category', $cat->slug)); ?>">-->
                        <!--                    <?php if(session()->get('language') == 'bangla'): ?>
-->
                        <!--                        <?php echo e($cat->name_bn); ?>-->
                    <!--                    <?php else: ?>-->
                        <!--                        <?php echo e($cat->name_en); ?>-->
                        <!--
<?php endif; ?>-->
                        <!--                </a>-->
                        <!--                <?php if($category->sub_categories && count($category->sub_categories) > 0): ?>
-->
                        <!--                    <ul class="dropdown">-->
                        <!--                        <?php $__currentLoopData = $category->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
-->
                        <!--                            <li>-->
                        <!--                                <a href="<?php echo e(route('product.category', $subcategory->slug)); ?>">-->
                        <!--                                    <?php if(session()->get('language') == 'bangla'): ?>
-->
                        <!--                                        <?php echo e($subcategory->name_bn); ?>-->
                    <!--                                    <?php else: ?>-->
                        <!--                                        <?php echo e($subcategory->name_en); ?>-->
                        <!--
<?php endif; ?>-->
                        <!--                                </a>-->
                        <!--                            </li>-->
                        <!--
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                        <!--                        <?php if($subcategory->sub_sub_categories && count($subcategory->sub_sub_categories) > 0): ?>
-->
                        <!--                            <ul class="dropdown">-->
                        <!--                                <?php $__currentLoopData = $subcategory->sub_sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
-->
                        <!--                                    <li>-->
                        <!--                                        <a-->
                        <!--                                            href="<?php echo e(route('product.category', $subsubcategory->slug)); ?>">-->
                        <!--                                            <?php if(session()->get('language') == 'bangla'): ?>
-->
                        <!--                                                <?php echo e($subsubcategory->name_bn); ?>-->
                    <!--                                            <?php else: ?>-->
                        <!--                                                <?php echo e($subsubcategory->name_en); ?>-->
                        <!--
<?php endif; ?>-->
                        <!--                                        </a>-->
                        <!--                                    </li>-->
                        <!--
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                        <!--                            </ul>-->
                        <!--
<?php endif; ?>-->
                        <!--                    </ul>-->
                        <!--
<?php endif; ?>-->
                        <!--            </li>-->
                        <!--        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                        <!--    </ul>-->
                        <!--</li>-->
                        
                    </ul>
                </nav>
                <!-- mobile menu end -->
            </div>
            
            
            
        </div>
    </div>
</div>
<!-- Mobile Side menu End -->
<!--End header-->

<?php $__env->startPush('footer-script'); ?>
    <script type="text/javascript">
        /* ================ Advance Product Search ============ */
        $("body").on("keyup", ".search", function() {
            let text = $(".search").val();
            let category_id = $("#searchCategory").val();
            // alert(category_id);
            // console.log(text);

            if (text.length > 0) {

                $.ajax({
                    data: {
                        search: text,
                        category: category_id
                    },
                    url: "/search-product",
                    method: 'post',
                    beforSend: function(request) {
                        return request.setReuestHeader('X-CSRF-Token', ("meta[name='csrf-token']"))

                    },
                    success: function(result) {
                        $(".searchProducts").html(result);
                    }

                }); // end ajax
            } // end if
            if (text.length < 1) $(".searchProducts").html("");
        }); // end function

        /* ================ Advance Product slideUp/slideDown ============ */
        function search_result_hide() {
            $(".searchProducts").slideUp();
        }

        function search_result_show() {
            $(".searchProducts").slideDown();
        }
    </script>

    <script>
        $(document).ready(function() {
            $(".show").click(function() {
                $(".advance-search").show();
            });
            $(".hide").click(function() {
                $(".advance-search").hide();
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/body/header.blade.php ENDPATH**/ ?>