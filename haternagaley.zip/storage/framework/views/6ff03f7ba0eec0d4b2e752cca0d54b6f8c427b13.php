
<?php $__env->startSection('content-frontend'); ?>
    <?php echo $__env->make('frontend.common.add_to_cart_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title'); ?>
    Category Nest Online Shop
<?php $__env->stopSection(); ?>
<main class="main">
    <div class="page-header mt-30 mb-50">
        <div class="container">
            
            <div class="archive-header">
                <div class="row align-items-center">
                    <div class="col-12">
                        <h2 class="mb-15">
                            <?php if(session()->get('language') == 'bangla'): ?>
                                <?php echo e($category->name_bn); ?>

                            <?php else: ?>
                                <?php echo e($category->name_en); ?>

                            <?php endif; ?>
                        </h2>
                        <div class="breadcrumb">
                            <a href="<?php echo e(route('home')); ?>" rel="nofollow"><i class="mr-5 fi-rs-home"></i>Home</a>
                            <span></span>
                            <?php if(session()->get('language') == 'bangla'): ?>
                                <?php echo e($category->name_bn); ?>

                            <?php else: ?>
                                <?php echo e($category->name_en); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="container mb-30">
        <div class="row">
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mr-20 card-2 bg-9 d-flex flex-column justify-content-center align-items-center wow animate__ animate__fadeInUp slick-slide slick-current slick-active"
                    data-wow-delay=".1s" data-slick-index="0" aria-hidden="false" tabindex="0"
                    style="width: 137px; visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                    <figure class="overflow-hidden img-hover-scale">
                        <a href="<?php echo e(route('product.category', $subcategory->slug)); ?>">
                            <?php if($subcategory->image && $subcategory->image != '' && $subcategory->image != 'Null'): ?>
                                <img class="default-img" src="<?php echo e(asset($subcategory->image)); ?>" alt="" />
                            <?php else: ?>
                                <img class="mb-3 img-lg" src="<?php echo e(asset('upload/no_image.jpg')); ?>" alt="" />
                            <?php endif; ?>
                        </a>
                    </figure>
                    <h6>
                        <a href="<?php echo e(route('product.category', $subcategory->slug)); ?>"
                            tabindex="0"><?php echo e($subcategory->name_en); ?></a>
                    </h6>
                    <!--   <span>26 items</span> -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="container mb-30">
        <div class="row">
            <div class="col-lg-4-5">
                <div class="shop-product-fillter">
                    <div class="totall-product">
                        <p>We found <strong class="text-brand"><?php echo e(count($products)); ?></strong> items for you!</p>
                    </div>
                    <div class="sort-by-product-area">
                        <div class="sort-by-cover d-flex">
                            <div class="row">
                                <div class="form-group col-lg-6 col-6 col-md-6">
                                    <div class="custom_select">
                                        <select class="form-control select-active" onchange="filter()" name="brand">
                                            <option value="">All Brands</option>
                                            <?php $__currentLoopData = \App\Models\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand->slug); ?>"
                                                    <?php if($brand_id == $brand->id): ?> selected <?php endif; ?>>
                                                    <?php echo e($brand->name_en ?? 'Null'); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-lg-6 col-6 col-md-6">
                                    <div class="custom_select">
                                        <select class="form-control select-active" name="sort_by" onchange="filter()">
                                            <option value="newest" <?php if($sort_by == 'newest'): ?> selected <?php endif; ?>>
                                                Newest</option>
                                            <option value="oldest" <?php if($sort_by == 'oldest'): ?> selected <?php endif; ?>>
                                                Oldest</option>
                                            <option value="price-asc" <?php if($sort_by == 'price-asc'): ?> selected <?php endif; ?>>
                                                Price Low to High</option>
                                            <option value="price-desc"
                                                <?php if($sort_by == 'price-desc'): ?> selected <?php endif; ?>>Price High to Low
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row product-grid">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('frontend.common.product_grid_view', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if(session()->get('language') == 'bangla'): ?>
                            <h5 class="text-danger">এখানে কোন পণ্য খুঁজে পাওয়া যায়নি!</h5>
                        <?php else: ?>
                            <h5 class="text-danger">No products were found here!</h5>
                        <?php endif; ?>
                    <?php endif; ?>
                    <!--end product card-->
                </div>
                <!--product grid-->
                <div class="mt-20 mb-20 pagination-area">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end">
                            <?php echo e($products->links()); ?>

                        </ul>
                    </nav>
                </div>
            </div>
            <div class="col-lg-1-5 primary-sidebar sticky-sidebar">
                <!-- Fillter By Price -->
                <?php echo $__env->make('frontend.common.filterby', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- SideCategory -->
                <?php echo $__env->make('frontend.common.sidecategory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer-script'); ?>
<script type="text/javascript">
    function filter() {
        $('#search-form').submit();
        //$("input:text").val("Glenn Quagmire");
    }
</script>

<script type="text/javascript">
    function sort_price_filter() {
        var start = $('#slider-range-value1').html();
        var end = $('#slider-range-value2').html();
        $('#filter_price_start').val(start);
        $('#filter_price_end').val(end);
        $('#search-form').submit();
    }
</script>

<script type="text/javascript">
    (function($) {
        ("use strict");
        // Slider Range JS
        if ($("#slider-range").length) {
            $(".noUi-handle").on("click", function() {
                $(this).width(50);
            });
            var rangeSlider = document.getElementById("slider-range");
            var moneyFormat = wNumb({
                decimals: 0,
                // thousand: ",",
                // prefix: "$"
            });
            var start_price = document.getElementById("filter_price_start").value;
            var end_price = document.getElementById("filter_price_end").value;
            noUiSlider.create(rangeSlider, {
                start: [start_price, end_price],
                step: 1,
                range: {
                    min: [1],
                    max: [10000]
                },
                format: moneyFormat,
                connect: true
            });

            // Set visual min and max values and also update value hidden form inputs
            rangeSlider.noUiSlider.on("update", function(values, handle) {
                document.getElementById("slider-range-value1").innerHTML = values[0];
                document.getElementById("slider-range-value2").innerHTML = values[1];
                document.getElementsByName("min-value").value = moneyFormat.from(values[0]);
                document.getElementsByName("max-value").value = moneyFormat.from(values[1]);

                // if(values[0]>1 || values[1]<200000){
                //     //sort_price_filter();
                // }
                //sort_price_filter();
                //console.log(handle);
            });

        }
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/product/category_view.blade.php ENDPATH**/ ?>