<?php $__env->startSection('content-frontend-model'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-frontend'); ?>
    <?php echo $__env->make('frontend.common.add_to_cart_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="main product-shop">
        <div class="container mb-30 mt-60">
            <div class="row">
                <div class="col-lg-4-5">
                    <form class="" id="search-form" action="" method="GET">
                        <div class="shop-product-fillter">
                            <div class="totall-product">
                                <p>We found <strong class="text-brand"><?php echo e(count($products)); ?></strong> items for you!</p>
                            </div>
                            <div class="sort-by-product-area">
                                <div class="sort-by-cover d-flex">
                                    <div class="row">
                                        <div class="form-group col-lg-6 col-6 col-md-6">
                                            <div class="custom_select">
                                                <select class="form-control select-active" onchange="filter()"
                                                    name="brand" id="brand_id">
                                                    <option value="">All Brands</option>
                                                    <?php $__currentLoopData = \App\Models\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($brand->id); ?>"
                                                            <?php if($brand_id == $brand->id): ?> selected <?php endif; ?>>
                                                            <?php echo e($brand->name_en ?? 'Null'); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-6 col-6 col-md-6">
                                            <div class="custom_select">
                                                <select class="form-control select-active" name="sort_by"
                                                    onchange="filter()">
                                                    <option value="newest"
                                                        <?php if($sort_by == 'newest'): ?> selected <?php endif; ?>>Newest</option>
                                                    <option value="oldest"
                                                        <?php if($sort_by == 'oldest'): ?> selected <?php endif; ?>>Oldest</option>
                                                    <option value="price-asc"
                                                        <?php if($sort_by == 'price-asc'): ?> selected <?php endif; ?>>Price Low to High
                                                    </option>
                                                    <option value="price-desc"
                                                        <?php if($sort_by == 'price-desc'): ?> selected <?php endif; ?>>Price High to Low
                                                    </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row product-grid product__grid gutters-5">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-lg-1-5 col-md-4 col-6 col-sm-6">
                                    <div class="mb-10 product-cart-wrap">
                                        <div class="product-img-action-wrap">
                                            <div class="product-img product-img-zoom">
                                                <a href="<?php echo e(route('product.details', $product->slug)); ?>">
                                                    <?php if($product->product_thumbnail && $product->product_thumbnail != '' && $product->product_thumbnail != 'Null'): ?>
                                                        <img class="default-img"
                                                            src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="" />
                                                        <img class="hover-img"
                                                            src="<?php echo e(asset($product->product_thumbnail)); ?>" alt="" />
                                                    <?php else: ?>
                                                        <img class="mb-3 img-lg" src="<?php echo e(asset('upload/no_image.jpg')); ?>"
                                                            alt="" />
                                                    <?php endif; ?>
                                                </a>
                                            </div>
                                            <div class="product-action-1 d-flex">
                                                <a aria-label="Quick view" id="<?php echo e($product->id); ?>"
                                                    onclick="productView(this.id)" class="action-btn" data-bs-toggle="modal"
                                                    data-bs-target="#quickViewModal"><i class="fi-rs-eye"></i></a>
                                            </div>
                                            <div class="product-badges product-badges-position product-badges-mrg">
                                                <?php
                                                    if ($product->discount_type == 1) {
                                                        $price_after_discount =
                                                            $product->regular_price - $product->discount_price;
                                                    } elseif ($product->discount_type == 2) {
                                                        $price_after_discount =
                                                            $product->regular_price -
                                                            ($product->regular_price * $product->discount_price) / 100;
                                                    }
                                                ?>

                                                <?php if($product->discount_price > 0): ?>
                                                    <div
                                                        class="product-badges-right product-badges-position-right product-badges-mrg">
                                                        <?php if($product->discount_type == 1): ?>
                                                            <span class="hot"><?php echo e($product->discount_price); ?>৳ off</span>
                                                        <?php elseif($product->discount_type == 2): ?>
                                                            <span class="hot"><?php echo e($product->discount_price); ?>% off</span>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="pb-0 product-content-wrap">
                                            

                                            <h2>
                                                <a href="<?php echo e(route('product.details', $product->slug)); ?>">
                                                    
                                                    <?php if(session()->get('language') == 'bangla'): ?>
                                                        <?php echo e($product->name_bn); ?>

                                                    <?php else: ?>
                                                        <?php echo e($product->name_en); ?>

                                                    <?php endif; ?>
                                                </a>
                                            </h2>
                                            
                                            <div class="product-card-bottom">
                                                <?php if($product->discount_price > 0): ?>
                                                    <div class="product-price">
                                                        <span class="price"> <?php echo e($price_after_discount); ?>৳ </span>
                                                        <span class="old-price"> <?php echo e($product->regular_price); ?>৳</span>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="product-price">
                                                        <span class="price"> <?php echo e($product->regular_price); ?>৳ </span>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="add-cart">
                                                    <?php if($product->is_varient == 1): ?>
                                                        
                                                        <a class="add addBtn"
                                                            onclick="addToCartDirect(<?php echo e($product->id); ?>)">কার্ট </a>

                                                        <a class="add addBuy" href=""
                                                            style="background: #AE6BCA">অর্ডার </a>
                                                    <?php else: ?>
                                                        
                                                        <a class="add addBtn"
                                                            onclick="addToCartDirect(<?php echo e($product->id); ?>)">কার্ট</a>

                                                        <a class="add addBuy" onclick="buyNowdirect(<?php echo e($product->id); ?>)"
                                                            style="background: #AE6BCA">অর্ডার </a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php if(session()->get('language') == 'bangla'): ?>
                                    <h5 class="text-danger">এখানে কোন পণ্য খুঁজে পাওয়া যায়নি!</h5>
                                <?php else: ?>
                                    <h5 class="text-danger">No products were found here!</h5>
                                <?php endif; ?>
                            <?php endif; ?>
                            <!--end product card-->
                        </div>
                        <!--product grid-->
                        <div class="mt-20 mb-20 pagination-area">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-end">
                                    <?php echo e($products->links()); ?>

                                </ul>
                            </nav>
                        </div>
                    </form>
                    <!--End Deals-->
                </div>
                <!-- Side Filter Start -->
                <div class="col-lg-1-5 primary-sidebar sticky-sidebar">
                    <form action="<?php echo e(URL::current()); ?>" method="GET" id="search-form">
                        <div class="card">
                            <div class="border-0 sidebar-widget price_range range">
                                <h5 class="mb-20">By Price</h5>
                                <div class="price-filter mb-30">
                                    <div class="price-filter-inner">
                                        <div id="slider-range" class="mb-20"></div>
                                        <div class="d-flex justify-content-between">
                                            <div class="caption">From: <strong id="slider-range-value1" class="text-brand">
                                                    <?php if(isset($_GET['filter_price_start'])): ?>
                                                        <?php echo e($_GET['filter_price_start']); ?>

                                                    <?php endif; ?>
                                                </strong></div>
                                            <div class="caption">To: <strong id="slider-range-value2"
                                                    class="text-brand"></strong></div>
                                        </div>
                                    </div>
                                </div>

                                <input type="hidden" id="filter_price_start" name="filter_price_start"
                                    <?php if(isset($_GET['filter_price_start'])): ?> value="<?php echo e($_GET['filter_price_start']); ?>" <?php else: ?> value="1" <?php endif; ?>>
                                <input type="hidden" id="filter_price_end" name="filter_price_end"
                                    <?php if(isset($_GET['filter_price_end'])): ?> value="<?php echo e($_GET['filter_price_end']); ?>" <?php else: ?> value="10000" <?php endif; ?>>

                                <h5 class="mb-20">Category</h5>
                                <div class="custome-checkbox">
                                    <?php $__currentLoopData = get_categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-2">
                                            <?php
                                                $checked = [];
                                                if (isset($_GET['filtercategory'])) {
                                                    $checked = $_GET['filtercategory'];
                                                }
                                            ?>
                                            <input class="form-check-input" type="checkbox" name="filtercategory[]"
                                                id="category_<?php echo e($category->id); ?>" value="<?php echo e($category->name_en); ?>"
                                                <?php if(in_array($category->name_en, $checked)): ?> checked <?php endif; ?> />
                                            <label class="form-check-label" for="category_<?php echo e($category->id); ?>">
                                                <span>
                                                    <?php if(session()->get('language') == 'bangla'): ?>
                                                        <?php echo e($category->name_bn); ?>

                                                    <?php else: ?>
                                                        <?php echo e($category->name_en); ?>

                                                    <?php endif; ?>
                                                </span>
                                            </label>
                                            <span class="float-end"><?php echo e(count($category->products)); ?></span>
                                            <br>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <button type="submin" class="mt-20 mb-10 btn btn-sm btn-default"
                                    onclick="sort_price_filter()"><i class="mr-5 fi-rs-filter"></i> Fillter</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Side Filter End -->
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer-script'); ?>
    <script type="text/javascript">
        function filter() {
            $('#search-form').submit();
            //$("input:text").val("Glenn Quagmire");
        }
    </script>

    <script type="text/javascript">
        function sort_price_filter() {
            var start = $('#slider-range-value1').html();
            var end = $('#slider-range-value2').html();
            $('#filter_price_start').val(start);
            $('#filter_price_end').val(end);
            $('#search-form').submit();
        }
    </script>

    <script type="text/javascript">
        (function($) {
            ("use strict");
            // Slider Range JS
            if ($("#slider-range").length) {
                $(".noUi-handle").on("click", function() {
                    $(this).width(50);
                });
                var rangeSlider = document.getElementById("slider-range");
                var moneyFormat = wNumb({
                    decimals: 0,
                    // thousand: ",",
                    // prefix: "$"
                });
                var start_price = document.getElementById("filter_price_start").value;
                var end_price = document.getElementById("filter_price_end").value;
                noUiSlider.create(rangeSlider, {
                    start: [start_price, end_price],
                    step: 1,
                    range: {
                        min: [1],
                        max: [10000]
                    },
                    format: moneyFormat,
                    connect: true
                });

                // Set visual min and max values and also update value hidden form inputs
                rangeSlider.noUiSlider.on("update", function(values, handle) {
                    document.getElementById("slider-range-value1").innerHTML = values[0];
                    document.getElementById("slider-range-value2").innerHTML = values[1];
                    document.getElementsByName("min-value").value = moneyFormat.from(values[0]);
                    document.getElementsByName("max-value").value = moneyFormat.from(values[1]);

                    // if(values[0]>1 || values[1]<200000){
                    //     //sort_price_filter();
                    // }
                    //sort_price_filter();
                    //console.log(handle);
                });

            }
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/product/product_shop.blade.php ENDPATH**/ ?>