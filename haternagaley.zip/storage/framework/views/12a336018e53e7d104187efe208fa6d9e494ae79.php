<style>
    .form-control {
        border-radius: 0px;
    }

    .form-group input {
        height: 45px !important;
    }

    button.submit,
    button[type="submit"] {
        padding: 5px 20px;
        border-radius: 0px;
    }
</style>
<footer class="main footer-dark">
    <section class="newsletter mb-15 wow animate__animated animate__fadeIn d-none d-md-block">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="position-relative newsletter-inner">
                        <div class="newsletter-content">
                            <h2 class="mb-20">
                                <?php if(get_footer_banner()): ?>
                                    <?php if(session()->get('language') == 'bangla'): ?>
                                        <?php echo e(get_footer_banner()->title_bn); ?>

                                    <?php else: ?>
                                        <?php echo e(get_footer_banner()->title_en); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                            </h2>
                            <p class="mb-110">
                                <?php if(get_footer_banner()): ?>
                                    <?php if(session()->get('language') == 'bangla'): ?>
                                        <?php $b_description_bn = strip_tags(html_entity_decode(get_footer_banner()->description_bn)); ?>
                                        <?php echo e(Str::limit($b_description_bn, $limit = 30, $end = '. . .')); ?>

                                    <?php else: ?>
                                        <?php $b_description_en = strip_tags(html_entity_decode(get_footer_banner()->description_en)); ?>
                                        <?php echo e(Str::limit($b_description_en, $limit = 30, $end = '. . .')); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                                
                            </p>
                            <form class="form-subcriber d-flex" method="POST"
                                action="<?php echo e(route('subscribers.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="email" placeholder="Your emaill address" required="" name="email" />
                                <button class="btn" type="submit">Subscribe</button>
                            </form>
                        </div>
                        <?php if(get_footer_banner()): ?>
                            <img src="<?php echo e(asset(get_footer_banner()->banner_img)); ?>" alt="newsletter" />
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <section class="section-padding footer-mid dark-section main-footer-custom">
        <div class="container pt-15 pb-20">
            <div class="row">
                <div class="col-lg-4 col-md-3 col-sm-6 col-12">
                    <div class="widget-about font-md mb-md-3 mb-lg-3 mb-xl-0 wow animate__animated animate__fadeInUp"
                        data-wow-delay="0">
                        <div class="logo mb-30">
                            <a href="<?php echo e(route('home')); ?>" class="mb-15">
                                <?php
                                    $logo = get_setting('site_footer_logo');
                                ?>
                                <?php if($logo != null): ?>
                                    <img src="<?php echo e(asset(get_setting('site_footer_logo')->value ?? 'null')); ?>"
                                        alt="<?php echo e(env('APP_NAME')); ?>" class="w-50">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('upload/no_image.jpg')); ?>" alt="<?php echo e(env('APP_NAME')); ?>"
                                        style="height: 60px !important; width: 80px !important; min-width: 80px !important;">
                                <?php endif; ?>
                            </a>

                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-sm-6 col-md-9 col-12">
                    <div class="row">
                        <div class="col-sm-6 col-md-3 col-6">
                            <div class="footer-link-widget wow animate__animated animate__fadeInUp"
                                data-wow-delay=".2s">
                                <h4 class="widget-title">Account</h4>
                                <ul class="footer-list mb-sm-5 mb-md-0">
                                    <li><a href="<?php echo e(route('login')); ?>">Sign In</a></li>
                                    <li><a href="<?php echo e(route('cart.show')); ?>">View Cart</a></li>
                                    <li><a href="<?php echo e(route('resellerapply.page')); ?>">Apply as Reseller</a></li>
                                    <li><a href="#" data-bs-toggle="modal" data-bs-target="#vendor_service"
                                            class="vendorBtn">Become a Vendor</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-6">
                            <div class="footer-link-widget wow animate__animated animate__fadeInUp"
                                data-wow-delay=".1s">
                                <h4 class="widget-title">Company</h4>
                                <ul class="footer-list mb-sm-5 mb-md-0">
                                    <?php $__currentLoopData = get_pages_both_footer(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('page.about', $page->slug)); ?>">
                                                <?php echo e($page->title); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="ms-xl-auto col-md-5 col-12 mr-0">
                            <div class="footer-link-widget wow animate__animated animate__fadeInUp"
                                data-wow-delay=".1s">
                                <h4 class="widget-title">Contact Info</h4>
                                <ul class="contact-infor">
                                    <li><img src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-location.svg')); ?>"
                                            alt="" /><strong>Address: </strong>
                                        <span><?php echo e(get_setting('business_address')->value ?? 'null'); ?></span></li>
                                    <li><img src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-contact.svg')); ?>"
                                            alt="" /><strong>Call Us: </strong><a
                                            href="tel:<?php echo e(get_setting('phone')->value ?? 'null'); ?>"><?php echo e(get_setting('phone')->value ?? 'null'); ?></a>
                                    </li>
                                    <li><img src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-email-2.svg')); ?>"
                                            alt="" /><strong>Email: </strong><a
                                            href="mailto:<?php echo e(get_setting('email')->value ?? 'null'); ?>"><?php echo e(get_setting('email')->value ?? 'null'); ?></a>
                                    </li>
                                    <li><img src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-clock.svg')); ?>"
                                            alt="" /><strong>Hours:</strong><span>
                                            <?php echo e(get_setting('business_hours')->value ?? 'null'); ?></span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <div class="pb-30 wow animate__animated animate__fadeInUp dark-section" data-wow-delay="0">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 mb-30">
                    <div class="footer-bottom"></div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <p class="font-sm mb-0">&copy; <?php echo e(get_setting('copy_right')->value ?? 'null'); ?><br />All rights
                        reserved</p>
                </div>
                <div class="col-xl-4 col-lg-6 text-center d-none d-xl-block">
                    <div class="mobile-social-icon justify-content-center">
                        <h6>Follow Us</h6>
                        <a target="_blank" href="<?php echo e(get_setting('facebook_url')->value ?? 'null'); ?>"><img
                                src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-facebook-white.svg')); ?>"
                                alt="" /></a>
                        <a target="_blank" href="<?php echo e(get_setting('twitter_url')->value ?? 'null'); ?>"><img
                                src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-twitter-white.svg')); ?>"
                                alt="" /></a>
                        <a target="_blank" href="<?php echo e(get_setting('instagram_url')->value ?? 'null'); ?>"><img
                                src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-instagram-white.svg')); ?>"
                                alt="" /></a>
                        <a target="_blank" href="<?php echo e(get_setting('pinterest_url')->value ?? 'null'); ?>"><img
                                src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-pinterest-white.svg')); ?>"
                                alt="" /></a>
                        <a target="_blank" href="<?php echo e(get_setting('youtube_url')->value ?? 'null'); ?>"><img
                                src="<?php echo e(asset('frontend/assets/imgs/theme/icons/icon-youtube-white.svg')); ?>"
                                alt="" /></a>
                    </div>
                    <p class="font-sm">
                        Developed by:
                        <a target="_blank" href="https://classicit.com.bd/">Classic IT & Sky Mart Ltd</a>
                    </p>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6 text-end d-none d-md-block">
                    <a href="#">
                        <img class="" src="<?php echo e(asset('frontend/assets/imgs/theme/payment-method.png')); ?>"
                            alt="" />
                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>

<?php
    $prefix = Request::route()->getPrefix();
    $route = Route::current()->getName();
?>
<div class="nest-mobile-bottom-nav d-xl-none mobile_fixed_bottom bg-white shadow-lg border-top rounded-top"
    style="box-shadow: 0px -1px 10px rgb(0 0 0 / 15%)!important; ">
    <div class="row align-items-center gutters-5">
        <div class="col mobile_bottom_nav_col">
            <a href="<?php echo e(route('home')); ?>" class="text-reset d-block text-center pb-2 pt-3">
                <i class="fas fa-home fs-20 opacity-60 opacity-100 <?php echo e($route == 'home' ? 'text-brand' : ''); ?>"></i>
                <span class="d-block fs-10 fw-600">Home</span>
            </a>
        </div>
        <div class="col mobile_bottom_nav_col">
            <a href="<?php echo e(route('product.show')); ?>" class="text-reset d-block text-center pb-2 pt-3">
                <span class="d-inline-block position-relative px-2">
                    <i
                        class="fa-sharp fa-solid fa-bag-shopping <?php echo e($route == 'product.show' ? 'text-brand' : ''); ?>"></i>
                </span>
                <span class="d-block fs-10 fw-600">Shop</span>
            </a>
        </div>
        <div class="col-auto">
            <a href="<?php echo e(route('cart.show')); ?>" class="text-reset d-block text-center pb-2 pt-3">
                <span class="mobile-card-nav align-items-center d-flex justify-content-center position-relative"
                    style="margin-top: -33px;box-shadow: 0px -5px 10px rgb(0 0 0 / 15%);border-color: #fff !important;">
                    <i class="fa-solid fa-cart-shopping la-2x text-white"></i>
                </span>
                <span class="d-block mt-1 fs-10 fw-600">
                    Cart
                    (<span class="cart-count cartQty"></span>)
                </span>
            </a>
        </div>
        <div class="col mobile_bottom_nav_col">
            <a href="<?php echo e(route('category_list.index')); ?>" class="text-reset d-block text-center pb-2 pt-3">
                <i
                    class="fas fa-list-ul fs-20 opacity-60 <?php echo e($route == 'category_list.index' ? 'text-brand' : ''); ?>"></i>
                <span class="d-block fs-10 fw-600">Categories</span>
            </a>
        </div>
        <div class="col mobile_bottom_nav_col">
            <?php if(Auth()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>" class="text-reset d-block text-center pb-2 pt-3">
                    <span class="d-block mx-auto">
                        <img src="<?php echo e(asset('frontend/assets/imgs/avatar-place.png')); ?>"
                            class="rounded-circle mobile_bottom_nav_account">
                    </span>
                    <span class="d-block fs-10 fw-600">Account</span>
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-reset d-block text-center pb-2 pt-3">
                    <span class="d-block mx-auto">
                        <img src="<?php echo e(asset('frontend/assets/imgs/avatar-place.png')); ?>"
                            class="rounded-circle mobile_bottom_nav_account">
                    </span>
                    <span class="d-block fs-10 fw-600">Login</span>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- vendor Modal form -->
<div class="modal fade" id="vendor_service" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Vendor Apply Form</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(route('vendor.Sellerstore')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <h6 class="mb-2 border-bottom pb-2">Basic Information</h6>
                    <div class="form-group">
                        <label for="name"><strong>Name: </strong><span class="text-danger">*</span></label>
                        <input type="text" id="vendor_name" name="vendor_name" class="form-control"
                            placeholder="Enter Your Name" value="<?php echo e(old('vendor_name')); ?>">
                        <?php $__errorArgs = ['vendor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone"><strong>Phone Number: </strong><span
                                        class="text-danger">*</span></label>
                                <input type="text" id="phone" name="phone" class="form-control"
                                    placeholder="Enter Your Phone Number" value="<?php echo e(old('phone')); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email"><strong>Email: </strong><span
                                        class="text-danger">*</span></label>
                                <input type="email" id="email" name="email" class="form-control"
                                    placeholder="Enter Your Email" value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <img id="showImage3" class="rounded avatar-lg"
                                        src="<?php echo e(!empty($editData->profile_image) ? url('upload/admin_images/' . $editData->profile_image) : url('upload/no_image.jpg')); ?>"
                                        alt="Card image cap" width="100px" height="80px;">
                                </div>
                                <label for="nid"><strong>Nid Card: </strong> <span
                                        class="text-danger">*</span></label>
                                <input name="nid" class="form-control" type="file" id="image3">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <img id="showImage4" class="rounded avatar-lg"
                                        src="<?php echo e(!empty($editData->profile_image) ? url('upload/admin_images/' . $editData->profile_image) : url('upload/no_image.jpg')); ?>"
                                        alt="Card image cap" width="100px" height="80px;">
                                </div>
                                <label for="trade"><strong>Trade License(if any one have): </strong></label>
                                <input name="trade_license" class="form-control" type="file" id="image4">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password"><strong>Password : </strong><span
                                        class="text-danger">*</span></label>
                                <input class="form-control" id="password" type="password" name="password"
                                    placeholder="Enter Your Password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="cpassword"><strong>Confirm Password : </strong><span
                                        class="text-danger">*</span></label>
                                <input class="form-control" placeholder="Confirm Password" type="password"
                                    name="password_confirmation" id="rtpassword" />
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <h6 class="mb-2 border-bottom pb-2">Shop Information</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="shopname"><strong>Shop Name : </strong><span
                                        class="text-danger">*</span></label>
                                <input class="form-control" id="shop_name" type="text" name="shop_name"
                                    placeholder="Write vendor shop name" value="<?php echo e(old('shop_name')); ?>">
                                <?php $__errorArgs = ['shop_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="address"><strong>Address : </strong></label>
                                <input class="form-control" id="address" type="text" name="address"
                                    placeholder="Enter Your Address" value="<?php echo e(old('address')); ?>">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <img id="showImage1" class="rounded avatar-lg"
                                        src="<?php echo e(!empty($editData->profile_image) ? url('upload/admin_images/' . $editData->profile_image) : url('upload/no_image.jpg')); ?>"
                                        alt="Card image cap" width="100px" height="80px;">
                                </div>
                                <label for="image"><strong>Shop Profile : </strong></label>
                                <input name="shop_profile" class="form-control" type="file" id="image1">
                                <?php $__errorArgs = ['shop_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <img id="showImage2" class="rounded avatar-lg"
                                        src="<?php echo e(!empty($editData->profile_image) ? url('upload/admin_images/' . $editData->profile_image) : url('upload/no_image.jpg')); ?>"
                                        alt="Card image cap" width="100px" height="80px;">
                                </div>
                                <label for="image"><strong>Shop Cover Photo : </strong></label>
                                <input name="shop_cover" class="form-control" type="file" id="image2">
                                <?php $__errorArgs = ['shop_cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="shop"><strong>Bank Information</strong></label>
                        <textarea name="bank_information" id="bank_information" cols="30" rows="5" class="form-control"
                            placeholder="Enter Bank Information"></textarea>
                    </div>
                    <button type="submit" class="additional_menuBtn">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/body/footer.blade.php ENDPATH**/ ?>