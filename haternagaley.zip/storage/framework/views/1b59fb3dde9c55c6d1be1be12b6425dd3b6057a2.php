<?php $__env->startPush('css'); ?>
    <style>
        .app-figure {
            width: 100% !important;
            margin: 0px auto;
            border: 0px solid red;
            padding: 20px;
            position: relative;
            text-align: center;
        }

        .MagicZoom {
            display: none;
        }

        .MagicZoom.Active {
            display: block;
        }

        .selectors {
            margin-top: 10px;
        }

        .selectors .mz-thumb img {
            max-width: 56px;
        }

        @media  screen and (max-width: 1023px) {
            .app-figure {
                width: 99% !important;
                margin: 20px auto;
                padding: 0;
            }
        }
    </style>
    <!-- Image zoom -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/magiczoomplus/magiczoomplus.css')); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content-frontend'); ?>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">

                <div class="breadcrumb">
                    <a href="<?php echo e(route('product.category', $product->category->slug)); ?>" rel="nofollow"><i
                            class="mr-5 fi-rs-home"></i>
                        <?php if(session()->get('language') == 'bangla'): ?>
                            <?php echo e($product->category->name_bn ?? 'No Category'); ?>

                        <?php else: ?>
                            <?php echo e($product->category->name_en ?? 'No Category'); ?>

                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
        <div class="container mb-30">
            <div class="row">
                <div class="m-auto col-xl-11 col-lg-12">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="product-detail accordion-detail">
                                <div class="row mb-50 mt-30">
                                    <div class="border col-md-6 col-sm-12 col-xs-12 mb-md-0 mb-sm-5">

                                        <!-- Product Zoom Image -->
                                        <div class="app-figure" id="zoom-fig">
                                            <a id="Zoom-1" class="MagicZoom" title="Product Images."
                                                href="<?php echo e(asset($product->product_thumbnail)); ?>?h=1400"
                                                data-zoom-image-2x="<?php echo e(asset($product->product_thumbnail)); ?>"
                                                data-image-2x="<?php echo e(asset($product->product_thumbnail)); ?>">
                                                <img id="product_zoom_img" style="max-width: 500px;max-height: 500px;"
                                                    src="<?php echo e(asset($product->product_thumbnail)); ?>"
                                                    srcset="<?php echo e(asset($product->product_thumbnail)); ?>" alt="" />
                                            </a>
                                            <div class="selectors mt-30">
                                                <?php $__currentLoopData = $product->multi_imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a class="me-4" data-zoom-id="Zoom-1"
                                                        href="<?php echo e(asset($img->photo_name)); ?>"
                                                        data-image="<?php echo e(asset($img->photo_name)); ?>"
                                                        data-zoom-image-2x="<?php echo e(asset($img->photo_name)); ?>"
                                                        data-image-2x="<?php echo e(asset($img->photo_name)); ?>">
                                                        <img style="height: 100px !important;"
                                                            srcset="<?php echo e(asset($img->photo_name)); ?>" />
                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="selectors mt-30">
                                                <?php if($product->product_video): ?>
                                                    <div class="app-figure">
                                                        <iframe width="560" height="315"
                                                            src="<?php echo e($product->product_video); ?>" frameborder="0"
                                                            allowfullscreen></iframe>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <!-- Product Zoom Image End -->
                                    </div>
                                    <div class="border col-md-6 col-sm-12 col-xs-12">
                                        <div class="p-5 detail-info pr-30 pl-30">
                                            <?php
                                                $discount = 0;

                                                if (auth()->check() && auth()->user()->role == 7) {
                                                    $amount = $product->reseller_price;
                                                } else {
                                                    $amount = $product->regular_price;
                                                    if ($product->discount_price > 0) {
                                                        if ($product->discount_type == 1) {
                                                            $discount = $product->discount_price;
                                                            $amount = $product->regular_price - $discount;
                                                        } elseif ($product->discount_type == 2) {
                                                            $discount =
                                                                ($product->regular_price * $product->discount_price) /
                                                                100;
                                                            $amount = $product->regular_price - $discount;
                                                        } else {
                                                            $amount = $product->regular_price;
                                                        }
                                                    }
                                                }
                                            ?>
                                            <?php if($product->discount_price > 0): ?>
                                                <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                                    <span class="stock-status out-stock" style="display: none"> 3 % Off
                                                    </span>
                                                <?php else: ?>
                                                    <?php if($product->discount_type == 1): ?>
                                                        <span class="stock-status out-stock"> ৳<?php echo e($discount); ?> Off
                                                        </span>
                                                    <?php elseif($product->discount_type == 2): ?>
                                                        <span class="stock-status out-stock">
                                                            <?php echo e($product->discount_price); ?>% Off </span>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <input type="hidden" id="discount_amount" value="<?php echo e($discount); ?>">

                                            <h2 class="title-detail">
                                                <?php if(session()->get('language') == 'bangla'): ?>
                                                    <?php echo e($product->name_bn); ?>

                                                <?php else: ?>
                                                    <?php echo e($product->name_en); ?>

                                                <?php endif; ?>
                                            </h2>
                                            <div class="clearfix product-price-cover">
                                                <div class="float-left product-price primary-color">
                                                    <?php if($product->discount_price <= 0): ?>
                                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                                            <span
                                                                class="current-price text-brand">৳<?php echo e(number_format($product->reseller_price)); ?></span>
                                                        <?php else: ?>
                                                            <span
                                                                class="current-price text-brand">৳<?php echo e($product->regular_price); ?></span>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span class="current-price text-brand">৳<?php echo e($amount); ?></span>
                                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                                            <span class="save-price font-md color3 ml-15"
                                                                style="display:none;"> ৳<?php echo e($discount); ?> Off </span>
                                                        <?php else: ?>
                                                            <?php if($product->discount_type == 1): ?>
                                                                <span class="save-price font-md color3 ml-15">
                                                                    ৳<?php echo e($discount); ?> Off </span>
                                                            <?php elseif($product->discount_type == 2): ?>
                                                                <span
                                                                    class="save-price font-md color3 ml-15"><?php echo e($product->discount_price); ?>%
                                                                    Off</span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                                            <span class="old-price font-md ml-15"
                                                                style="display:none;">৳<?php echo e(number_format($product->reseller_price)); ?></span>
                                                        <?php else: ?>
                                                            <span
                                                                class="old-price font-md ml-15">৳<?php echo e($product->regular_price); ?></span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                                <div class="mb-10">
                                                    <span>Regular Price: <span class="text-info">৳
                                                            <?php echo e($product->regular_price); ?></span></span>
                                                </div>
                                            <?php endif; ?>
                                            <form id="choice_form">
                                                <div class="row " id="choice_attributes">
                                                    <?php if($product->is_varient): ?>
                                                        <?php $i=0; ?>
                                                        <?php $__currentLoopData = json_decode($product->attribute_values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $attr = get_attribute_by_id($attribute->attribute_id);
                                                                $i++;
                                                            ?>
                                                            <div class="attr-detail attr-size mb-30">
                                                                <strong class="mr-10"><?php echo e($attr->name); ?>: </strong>
                                                                <input type="hidden" name="attribute_ids[]"
                                                                    id="attribute_id_<?php echo e($i); ?>"
                                                                    value="<?php echo e($attribute->attribute_id); ?>">
                                                                <input type="hidden" name="attribute_names[]"
                                                                    id="attribute_name_<?php echo e($i); ?>"
                                                                    value="<?php echo e($attr->name); ?>">
                                                                <input type="hidden"
                                                                    id="attribute_check_<?php echo e($i); ?>"
                                                                    value="0">
                                                                <input type="hidden"
                                                                    id="attribute_check_attr_<?php echo e($i); ?>"
                                                                    value="0">
                                                                <ul class="list-filter size-filter font-small">
                                                                    <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li>
                                                                            <a href="#"
                                                                                onclick="selectAttribute('<?php echo e($attribute->attribute_id); ?><?php echo e($attr->name); ?>', '<?php echo e($value); ?>', '<?php echo e($product->id); ?>', '<?php echo e($i); ?>')"
                                                                                style="border: 1px solid #7E7E7E;"><?php echo e($value); ?></a>
                                                                        </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <input type="hidden" name="attribute_options[]"
                                                                        id="<?php echo e($attribute->attribute_id); ?><?php echo e($attr->name); ?>"
                                                                        class="attr_value_<?php echo e($i); ?>">
                                                                </ul>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <input type="hidden" id="total_attributes"
                                                            value="<?php echo e(count(json_decode($product->attribute_values))); ?>">
                                                        <!-- <?php $__currentLoopData = json_decode($product->attribute_values); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $attr = get_attribute_by_id($attribute->attribute_id);
        $i++;
    ?>
                                                                                                                                                                                                                                      <div class="form-group col-lg-4">
                                                                                                                                                                                                                                      <input type="hidden" name="attribute_ids[]" id="attribute_id_<?php echo e($i); ?>" value="<?php echo e($attribute->attribute_id); ?>">
                                                                                                                                                                                                                                      <input type="hidden" name="attribute_names[]" id="attribute_name_<?php echo e($i); ?>" value="<?php echo e($attr->name); ?>">
                                                                                                                                                                                                                                    <label style=" font-weight:bold;color: black;">Chose <?php echo e($attr->name); ?><span>**</span></label>
                                                                                                                                                                                                                                      <div class="custom_select">
                                                                                                                                                                                                                                      <select class="form-control select-active" name="attribute_options[]" id="attribute_option_<?php echo e($i); ?>">
                                                                                                                                                                                                                                      <option value="">--Chose <?php echo e($attr->name); ?>--</option>

                                                                                                                                                                                                                                      <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                                                                                                                                                                                      </select>
                                                                                                                                                                                                                                      </div>
                                                                                                                                                                                                                                      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                                    <?php endif; ?>
                                                </div>
                                            </form>

                                            <div class="row" id="attribute_alert">

                                            </div>
                                            

                                            <div class="mb-3 quantity">
                                                <a href="#" class="quantity__minus"><span><i
                                                            class="fa fa-minus"></i></span></a>
                                                <input name="quantity" type="text" readonly class="quantity__input"
                                                    value="1" min="1" id="qty">
                                                <a href="#" class="quantity__plus"><span><i
                                                            class="fa fa-plus"></i></span></a>
                                            </div>

                                            <div class="row" id="qty_alert">

                                            </div>

                                            <div class="detail-extralink mb-30">
                                                <div class="product-extra-link2 product_details_page">

                                                    <input type="hidden" id="product_id" value="<?php echo e($product->id); ?>"
                                                        min="1">

                                                    <input type="hidden" id="pname"
                                                        value="<?php echo e($product->name_en); ?>">

                                                    <input type="hidden" id="product_price"
                                                        value="<?php echo e($amount); ?>">

                                                    <input type="hidden" id="minimum_buy_qty"
                                                        value="<?php echo e($product->minimum_buy_qty); ?>">
                                                    <input type="hidden" id="stock_qty"
                                                        value="<?php echo e($product->stock_qty); ?>">

                                                    <input type="hidden" id="pvarient" value="">

                                                    <input type="hidden" id="buyNowCheck" value="0">

                                                    <div class="d-none show_cart_btn">
                                                        <button type="submit" class="button button-add-to-cart"
                                                            onclick="addToCart()"><i class="fi-rs-shoppi ng-cart"></i>Add
                                                            to cart</button>
                                                        <button type="submit"
                                                            class="ml-5 button button-add-to-cart bg-danger"
                                                            onclick="buyNow()"><i class="fi-rs-shoppi ng-cart"></i>Buy
                                                            Now</button>
                                                    </div>
                                                    <div class="remove_qty_btn">
                                                        <?php if($product->stock_qty > 0): ?>
                                                            <button type="submit" class="button button-add-to-cart"
                                                                onclick="addToCart()"><i
                                                                    class="fi-rs-shoppi ng-cart"></i>কার্ট</button>

                                                            <button type="submit" class="ml-5 button button-add-to-cart"
                                                                style="background: #AE6BCA !important"
                                                                onclick="buyNow()"><i
                                                                    class="fi-rs-shoppi ng-cart"></i>অর্ডার</button>
                                                        <?php else: ?>
                                                            <p class=" button bg-danger stock_out"
                                                                style="color: #ffffff !important;"><i
                                                                    class="mr-5 fas fa-window-close"></i>স্টক আউট</p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <button><a href="tel:+8801937563157"> <i class="fa fa-phone"
                                                            style="background: #0D9DFF;color: #fff; padding: 5px; font-size: 10px; border-radius: 100%;    margin-right: 5px;"></i>
                                                        01937563157</a></button>

                                            </div>
                                            <div class="mb-3 row" id="stock_alert">

                                            </div>
                                            <div class="font-xs">
                                                <ul class="mr-50 float-start">
                                                    <li class="mb-5"><strong>Regular Price:</strong> <span
                                                            class="text-brand"
                                                            style="font-size: 14px !important;"><?php echo e($product->regular_price); ?></span>
                                                    </li>
                                                    <li class="mb-5"><strong>Stock:</strong> <span
                                                            class="text-brand product_att_stock"
                                                            style="font-size: 14px !important;"><?php echo e($product->stock_qty); ?></span>
                                                    </li>
                                                    <li class="mb-5"><strong>Category:</strong><span class="text-brand"
                                                            style="font-size: 14px !important;">
                                                            <?php echo e($product->category->name_en ?? 'No Category'); ?>

                                                        </span></li>
                                                </ul>
                                                <ul class="float-start">
                                                    <?php if($product->wholesell_price > 0): ?>
                                                        <li class="mb-5" style="font-size: 14px !important;"><a
                                                                href="https://wa.me/+8801633178160" target="_blank">This
                                                                product is available in wholesale & Please contact with our
                                                                whatsapp.</a></li>
                                                    <?php endif; ?>
                                                    <li class="mb-5"><strong>Brand:</strong>
                                                        <a href="#" rel="tag">
                                                            <?php echo e($product->brand->name_en ?? 'No Brand'); ?>

                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div style="margin-top: 110px" class="product_shipping_charge">

                                                <i class="fa-solid fa-cubes"></i>
                                                <div>
                                                    <span>ঢাকার ভিতরে <strong>৭০</strong> টাকা <br></span>
                                                    <span>ঢাকার বাহিরে <strong>১২০</strong> টাকা <br></span>
                                                    <span>Free Shipping <br></span>
                                                </div>

                                            </div>
                                        </div>
                                        <!-- Detail Info -->
                                    </div>

                                </div>
                                <div class="product-info">
                                    <div class="tab-style3">
                                        <ul class="nav nav-tabs text-uppercase">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="Description-tab" data-bs-toggle="tab"
                                                    href="#Description">Description</a>
                                            </li>
                                            <!--<li class="nav-item">-->
                                            <!--    <a class="nav-link" id="Additional-info-tab" data-bs-toggle="tab" href="#Additional-info">Additional info</a>-->
                                            <!--</li>-->
                                            <?php if(get_setting('multi_vendor')->value): ?>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="Vendor-info-tab" data-bs-toggle="tab"
                                                        href="#Vendor-info">Seller</a>
                                                </li>
                                            <?php endif; ?>
                                            <li class="nav-item">
                                                <a class="nav-link" id="reviews-tab" data-bs-toggle="tab"
                                                    href="#reviews">Reviews</a>
                                            </li>
                                        </ul>
                                        <div class="tab-content shop_info_tab entry-main-content">
                                            <div class="tab-pane fade show active" id="Description">
                                                <div class="">
                                                    <p>
                                                        <?php if(session()->get('language') == 'bangla'): ?>
                                                            <?php echo $product->description_bn ?? 'No Product Long Descrption'; ?>

                                                        <?php else: ?>
                                                            <?php echo $product->description_en ?? 'No Product Logn Descrption'; ?>

                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </div>
                                            
                                            <?php if(get_setting('multi_vendor')->value): ?>
                                                <?php
                                                    $vendor = \App\Models\Vendor::where(
                                                        'id',
                                                        $product->vendor_id,
                                                    )->first();
                                                ?>
                                                <?php if($vendor): ?>
                                                    <div class="tab-pane fade" id="Vendor-info">
                                                        <div class="vendor-logo d-flex mb-30 align-items-center">
                                                            <img src="<?php echo e(asset($vendor->shop_profile)); ?>"
                                                                alt="" />
                                                            <div class="vendor-name ml-15">
                                                                <h6>
                                                                    <a
                                                                        href="<?php echo e(route('vendor.product', $vendor->slug)); ?>"><?php echo e($vendor->shop_name); ?></a>
                                                                </h6>
                                                                <!--<div class="product-rate-cover text-end">-->
                                                                <!--	<div class="product-rate d-inline-block">-->
                                                                <!--		<div class="product-rating" style="width: 90%"></div>-->
                                                                <!--	</div>-->
                                                                <!--	<span class="ml-5 font-small text-muted"> (32 reviews)</span>-->
                                                                <!--</div>-->
                                                            </div>
                                                        </div>
                                                        <ul class="contact-infor mb-50">
                                                            <li><img src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-location.svg"
                                                                    alt="" /><strong>Address: </strong>
                                                                <span><?php echo e($vendor->address); ?></span>
                                                            </li>
                                                            <!--<li><img src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-contact.svg" alt="" /><strong>Contact Seller:</strong><span>(+91) - 540-025-553</span></li>-->
                                                        </ul>
                                                        <!--<div class="d-flex mb-55">-->
                                                        <!--	<div class="mr-30">-->
                                                        <!--		<p class="text-brand font-xs">Rating</p>-->
                                                        <!--		<h4 class="mb-0">92%</h4>-->
                                                        <!--	</div>-->
                                                        <!--	<div class="mr-30">-->
                                                        <!--		<p class="text-brand font-xs">Ship on time</p>-->
                                                        <!--		<h4 class="mb-0">100%</h4>-->
                                                        <!--	</div>-->
                                                        <!--	<div>-->
                                                        <!--		<p class="text-brand font-xs">Chat response</p>-->
                                                        <!--		<h4 class="mb-0">89%</h4>-->
                                                        <!--	</div>-->
                                                        <!--</div>-->
                                                        <p>
                                                            <?php echo e($vendor->description); ?>

                                                        </p>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <div class="tab-pane fade" id="reviews">
                                                <div class="product__review__system">
                                                    <h6>Youre reviewing:</h6>
                                                    <h5 class="pt-4 pb-5">
                                                        <?php if(session()->get('language') == 'bangla'): ?>
                                                            <?php echo e($product->name_bn); ?>

                                                        <?php else: ?>
                                                            <?php echo e($product->name_en); ?>

                                                        <?php endif; ?>
                                                    </h5>
                                                    <form action="<?php echo e(route('review.store')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="product_id"
                                                            value="<?php echo e($product->id); ?>">
                                                        <input type="hidden" name="user_id"
                                                            value="<?php echo e(Auth::user()->id ?? 'null'); ?>">
                                                        <div class="product__rating"
                                                            style="padding-bottom:30px;padding-top:20px;">
                                                            <label for="rating"
                                                                style="font-size: 20px;color:green;font-weight:bold">Rating:<span
                                                                    class="text-danger">*</span></label>
                                                            <div class="rating-checked">
                                                                <input type="radio" name="rating" value="5"
                                                                    style="--r: #ffb301" />
                                                                <input type="radio" name="rating" value="4"
                                                                    style="--r: #ffb301" />
                                                                <input type="radio" name="rating" value="3"
                                                                    style="--r: #ffb301" />
                                                                <input type="radio" name="rating" value="2"
                                                                    style="--r: #ffb301" />
                                                                <input type="radio" name="rating" value="1"
                                                                    style="--r: #ffb301" />
                                                            </div>
                                                            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <p class="text-danger"><?php echo e($message); ?></p>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="review__form">
                                                            <div class="row">
                                                                
                                                                
                                                                <div class="col-md-6 col-12">
                                                                    <div class="form-group">
                                                                        <label for="review"
                                                                            style="font-size: 20px;">Review <span
                                                                                class="text-danger">*</span></label>
                                                                        <input type="text" name="review"
                                                                            id="review" value="<?php echo e(old('review')); ?>">
                                                                        <?php $__errorArgs = ['review'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <p class="text-danger"><?php echo e($message); ?>

                                                                            </p>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <button type="submit" class="btn btn-info">Submit
                                                                Review</button>
                                                        </div>
                                                    </form>
                                                    <div class="review_list">
                                                        <?php
                                                            $data = \App\Models\Review::where(
                                                                'product_id',
                                                                $product->id,
                                                            )
                                                                ->latest()
                                                                ->get();
                                                        ?>
                                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($value->status == 1): ?>
                                                                <div class="single-review-item">
                                                                    <div class="rating">
                                                                        <?php if($value->rating == '1'): ?>
                                                                            <i class="fa fa-star"></i>
                                                                        <?php elseif($value->rating == '2'): ?>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                        <?php elseif($value->rating == '3'): ?>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                        <?php elseif($value->rating == '4'): ?>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                        <?php elseif($value->rating == '5'): ?>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                            <i class="fa fa-star"></i>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <h5 class="review-title"><?php echo e($value->summary); ?>

                                                                    </h5>
                                                                    <h6 class="review-user"><?php echo e($value->name); ?>

                                                                    </h6>
                                                                    <span
                                                                        class="review-description"><?php echo $value->review; ?></span>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-60">
                                    <div class="col-12">
                                        <h2 class="section-title style-1 mb-30">Related products</h2>
                                    </div>
                                    <div class="col-12">
                                        <div class="row related-products">
                                            <?php $__empty_1 = true; $__currentLoopData = $relatedProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php echo $__env->make('frontend.common.product_grid_view', [
                                                    'product' => $product,
                                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <!--end product card-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php if(session()->get('language') == 'bangla'): ?>
                                                    <h5 class="text-danger">এখানে কোন পণ্য খুঁজে পাওয়া যায়নি!</h5>
                                                <?php else: ?>
                                                    <h5 class="text-danger">No products were found here!</h5>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footer-script'); ?>
    <!-- Image zoom -->
    <script src="<?php echo e(asset('frontend/magiczoomplus/magiczoomplus.js')); ?>"></script>
    <script>
        var mzOptions = {
            zoomWidth: "400px",
            zoomHeight: "400px",
            zoomDistance: 15,
            expandZoomMode: "magnifier",
            expandZoomOn: "always",
            variableZoom: true,
            // lazyZoom: true,
            // selectorTrigger: "hover"
        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/product/product_details.blade.php ENDPATH**/ ?>