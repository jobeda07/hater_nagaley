
<?php $__env->startSection('content-frontend'); ?>
<?php echo $__env->make('frontend.common.add_to_cart_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="main">
	<div class="container mb-30 mt-60">
	    <div class="row">
	        <div class="col-lg-4-5">
	            <div class="shop-product-fillter">
	                <div class="totall-product">
	                    <p>We found <strong class="text-brand"><?php echo e(count($products)); ?></strong> items for you!</p>
	                </div>
	                <div class="sort-by-product-area">
                        <div class="sort-by-cover d-flex">
                            <div class="row">
                                <div class="form-group col-lg-6 col-6 col-md-6">
                                    <div class="custom_select">
                                        <select class="form-control select-active" onchange="filter()" name="brand">
                                            <option value="">All Brands</option>
                                            <?php $__currentLoopData = \App\Models\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand->slug); ?>" <?php if($brand_id == $brand->id): ?> selected <?php endif; ?> ><?php echo e($brand->name_en ?? 'Null'); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>  
                                <div class="form-group col-lg-6 col-6 col-md-6">
                                    <div class="custom_select">
                                        <select class="form-control select-active" name="sort_by" onchange="filter()">
                                            <option value="newest" <?php if($sort_by =='newest'): ?> selected <?php endif; ?>>Newest</option>
                                            <option value="oldest" <?php if($sort_by =='oldest'): ?> selected <?php endif; ?> >Oldest</option>
                                            <option value="price-asc" <?php if($sort_by == 'price-asc'): ?> selected <?php endif; ?> >Price Low to High</option>
                                            <option value="price-desc" <?php if($sort_by == 'price-desc'): ?> selected <?php endif; ?> >Price High to Low</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
	            <div class="row product-grid gutters-5">
	            	<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	                   <?php echo $__env->make('frontend.common.product_grid_view',['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if(session()->get('language') == 'bangla'): ?> 
	                        <h5 class="text-danger">এখানে কোন পণ্য খুঁজে পাওয়া যায়নি!</h5> 
	                    <?php else: ?> 
	                       	<h5 class="text-danger">No products were found here!</h5> 
	                    <?php endif; ?>
	                <?php endif; ?>
	                <!--end product card-->
	            </div>
	            <!--product grid-->
                <!-- Pagination -->
	            <div class="pagination-area mt-20 mb-20">
	                <nav aria-label="Page navigation example">
	                    <ul class="pagination justify-content-end">
	                        <?php echo e($products->links()); ?>

	                    </ul>
	                </nav>
	            </div>
                <!-- Pagination -->
	        </div>
            <!-- Side Filter Start -->
	        <div class="col-lg-1-5 primary-sidebar sticky-sidebar">
                <form action="<?php echo e(URL::current()); ?>" method="GET">
                <div class="card">
                    <div class="sidebar-widget price_range range border-0">
                        <h5 class="mb-20">By Price</h5>
                        <div class="price-filter mb-20">
                            <div class="price-filter-inner">
                                <div id="slider-range" class="mb-20"></div>
                                <div class="d-flex justify-content-between">
                                    <div class="caption">From: <strong id="slider-range-value1" class="text-brand"></strong></div>
                                    <div class="caption">To: <strong id="slider-range-value2" class="text-brand"></strong></div>
                                </div>
                            </div>
                        </div>
                        <h5 class="mb-20">Category</h5>
                        <div class="custome-checkbox">
                            <?php $__currentLoopData = get_categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-2">
                                    <?php
                                        $checked = [];
                                        if(isset($_GET['filtercategory'])){
                                            $checked = $_GET['filtercategory'];
                                        }
                                    ?>
                                    <input class="form-check-input" type="checkbox" name="filtercategory[]" id="category_<?php echo e($category->id); ?>" value="<?php echo e($category->name_en); ?>" 
                                        <?php if(in_array($category->name_en, $checked)): ?> checked <?php endif; ?>
                                    />
                                    <label class="form-check-label" for="category_<?php echo e($category->id); ?>">
                                        <span>
                                            <?php if(session()->get('language') == 'bangla'): ?> 
                                                <?php echo e($category->name_bn); ?>

                                            <?php else: ?> 
                                                <?php echo e($category->name_en); ?> 
                                            <?php endif; ?> 
                                        </span>
                                    </label>
                                    <span class="float-end"><?php echo e(count($category->products)); ?></span>
                                    <br>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button type="submin" class="btn btn-sm btn-default mt-20 mb-10" ><i class="fi-rs-filter mr-5"></i> Fillter</button>
                    </div>
                </div>
                </form>
                <!--  -->
	        </div>
            <!-- Side Filter End -->
	    </div>
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/deals/hot_deals.blade.php ENDPATH**/ ?>