<div class="col-xl-3 col-lg-4 col-md-6 col-6">
    <div class="product-cart-wrap style-2">
        <div class="product-img-action-wrap">
            <div class="product-img">
                <a href="<?php echo e(route('product.details', $product->slug)); ?>">
                    <?php if($product->product_thumbnail && $product->product_thumbnail != '' && $product->product_thumbnail != 'Null'): ?>
                        <img class="default-img" data-original="<?php echo e(asset($product->product_thumbnail)); ?>" alt="" />
                    <?php else: ?>
                        <img class="mb-3 img-lg" data-original="<?php echo e(asset('upload/no_image.jpg')); ?>" alt="" />
                    <?php endif; ?>
                </a>
            </div>
        </div>
        <div class="product-content-wrap">
            <div class="deals-content">
                <h2>
                    <a href="<?php echo e(route('product.details', $product->slug)); ?>">
                        <?php if(session()->get('language') == 'bangla'): ?>
                            <?php $p_name_bn = strip_tags(html_entity_decode($product->name_bn)); ?>
                            <?php echo e(Str::limit($p_name_bn, $limit = 30, $end = '. . .')); ?>

                        <?php else: ?>
                            <?php $p_name_en = strip_tags(html_entity_decode($product->name_en)); ?>
                            <?php echo e(Str::limit($p_name_en, $limit = 30, $end = '. . .')); ?>

                        <?php endif; ?>
                    </a>
                </h2>
                <!-- <div class="product-rate-cover">
                    <div class="product-rate d-inline-block">
                        <div class="product-rating" style="width: 90%"></div>
                    </div>
                    <span class="ml-5 font-small text-muted"> (4.0)</span>
                </div> -->
                
                <?php
                    if (auth()->check() && auth()->user()->role == 7) {
                        if ($product->discount_type == 1) {
                            $price_after_discount = $product->reseller_price - $product->discount_price;
                        } elseif ($product->discount_type == 2) {
                            $price_after_discount =
                                $product->reseller_price - ($product->reseller_price * $product->discount_price) / 100;
                        }
                    } else {
                        if ($product->discount_type == 1) {
                            $price_after_discount = $product->regular_price - $product->discount_price;
                        } elseif ($product->discount_type == 2) {
                            $price_after_discount =
                                $product->regular_price - ($product->regular_price * $product->discount_price) / 100;
                        }
                    }
                ?>
                <div class="product-card-bottom">
                    <?php if($product->discount_price > 0): ?>
                        <div class="product-price">
                            <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                <span class="price"> ৳<?php echo e($product->reseller_price); ?> </span>
                            <?php else: ?>
                                <span class="price"> ৳<?php echo e($price_after_discount); ?> </span>
                            <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                <span class="old-price" style="display: none">৳<?php echo e($product->reseller_price); ?></span>
                            <?php else: ?>
                                <span class="old-price">৳<?php echo e($product->regular_price); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="product-price">
                            <?php if(auth()->check() && auth()->user()->role == 7): ?>
                                <span class="price"> ৳<?php echo e($product->reseller_price); ?> </span>
                            <?php else: ?>
                                <span class="price"> ৳<?php echo e($product->regular_price); ?> </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="add-cart">
                        <?php if($product->is_varient == 1): ?>
                            
                                    <a class="add addBtn" id="<?php echo e($product->id); ?>" onclick="productView(this.id)" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fi-rs-shopping-cart mr-5"></i>কার্ট </a>

                            <a class="add addBuy" id="<?php echo e($product->id); ?>" style="background: #AE6BCA" onclick="productView(this.id)" onclick="productView(this.id)" data-bs-toggle="modal" data-bs-target="#quickViewModal">অর্ডার</a>
                        <?php else: ?>
                            
                            <a class="add addBtn" onclick="addToCartDirect(<?php echo e($product->id); ?>)">কার্ট  </a>

                            <a class="add addBuy" onclick="buyNowdirect(<?php echo e($product->id); ?>)"
                                style="background: #AE6BCA">অর্ডার </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if(auth()->check() && auth()->user()->role == 7): ?>
                    <div>
                        <span>Regular Price: <span class="text-info">৳ <?php echo e($product->regular_price); ?></span></span>
                        <input type="hidden" id="regular_price" name="regular_price"
                            value="<?php echo e($product->regular_price); ?>" min="1">
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\New folder\haternagaley\resources\views/frontend/common/deals.blade.php ENDPATH**/ ?>